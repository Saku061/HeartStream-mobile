package com.example

import com.example.ai.EmbeddedEcgNetClassifier
import com.example.dsp.BpmCalculator
import com.example.dsp.EcgFilter
import com.example.dsp.RPeakDetector
import com.example.model.DeduplicationMode
import com.example.model.HeartbeatClass
import com.example.network.EcgDataParser
import com.example.network.ParsedEcgPacket
import com.example.network.RollingBufferDeduplicator
import com.example.network.SimulatorSource
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleUnitTest {

  @Test
  fun testEcgDataParser_StandardSchema() {
    val parser = EcgDataParser()
    val json = "{\"latest\": 512, \"samples\": [510, 512, 515, 520, 518, 513]}"
    val packet = parser.parse(json)

    assertEquals(512, packet.latestValue)
    assertEquals(6, packet.samples.size)
    assertEquals(510, packet.samples[0])
    assertEquals(513, packet.samples[5])
  }

  @Test
  fun testRollingBufferDeduplication() {
    val deduplicator = RollingBufferDeduplicator(100)
    val parser = EcgDataParser()

    // 1st buffer: [100, 101, 102, 103, 104]
    val p1 = parser.parse("{\"samples\": [100, 101, 102, 103, 104]}")
    val new1 = deduplicator.extractNewSamples(p1, DeduplicationMode.OVERLAP_SUFFIX)
    assertEquals(5, new1.size)

    // 2nd rolling buffer (resends 102, 103, 104, + new 105, 106)
    val p2 = parser.parse("{\"samples\": [102, 103, 104, 105, 106]}")
    val new2 = deduplicator.extractNewSamples(p2, DeduplicationMode.OVERLAP_SUFFIX)
    assertEquals(2, new2.size)
    assertEquals(listOf(105, 106), new2)

    // 3rd buffer is exact duplicate
    val new3 = deduplicator.extractNewSamples(p2, DeduplicationMode.OVERLAP_SUFFIX)
    assertEquals(0, new3.size)
    assertTrue(deduplicator.getDuplicateBuffersCount() >= 1L)
  }

  @Test
  fun testEcgFilter_Calibration() {
    val filter = EcgFilter(sampleRate = 250, vRef = 3.3f, adcMax = 1023, sensorGain = 1100f)
    // 512 is virtual ground -> should be approximately 0.0 mV
    val midMv = filter.rawToMillivolts(512)
    assertTrue("Zero baseline should be near 0 mV", kotlin.math.abs(midMv) < 0.01f)

    // R-peak at 750 ADC -> positive deflection
    val peakMv = filter.rawToMillivolts(750)
    assertTrue("R-peak should be positive mV", peakMv > 0.4f)
  }

  @Test
  fun testBpmCalculator_PlausibilityAndMedian() {
    val bpmCalc = BpmCalculator()
    // Simulated steady 75 BPM -> 800 ms RR interval
    var t = 1000L
    bpmCalc.onRPeakDetected(t, isSignalAdequate = true)

    t += 800L
    bpmCalc.onRPeakDetected(t, isSignalAdequate = true)

    t += 800L
    val bpm = bpmCalc.onRPeakDetected(t, isSignalAdequate = true)
    assertNotNull(bpm)
    assertEquals(75, bpm)

    // Outlier spike: 200ms interval (300 BPM) should be rejected
    t += 200L
    val rejectedBpm = bpmCalc.onRPeakDetected(t, isSignalAdequate = true)
    assertEquals(75, rejectedBpm)
  }

  @Test
  fun testEmbeddedClassifier_OutputsAll5Classes() {
    val classifier = EmbeddedEcgNetClassifier()
    val simulator = SimulatorSource(250)
    val normalBeat = simulator.generateBatch(250).map { (it - 512) / 200f }

    val result = classifier.classifyBeat(normalBeat, rrIntervalMs = 800L)
    assertNotNull(result)
    assertEquals(5, result!!.probabilities.size)

    // Probabilities should sum to approximately 1.0
    val probSum = result.probabilities.values.sum()
    assertTrue("Probabilities must sum to ~1.0", kotlin.math.abs(probSum - 1.0f) < 0.02f)
    assertEquals(HeartbeatClass.NORMAL, result.predictedClass)
  }
}
