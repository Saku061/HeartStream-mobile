package com.example.network

import com.example.model.HeartbeatClass
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * High-fidelity synthetic ECG generator at 250 Hz.
 * Emulates the AD8232 single-lead ECG front-end.
 * Supports realistic cardiac rhythm waveforms and injection of MIT-BIH arrhythmias:
 * Normal, LBBB, RBBB, APB, PVC, and sensor leads-off.
 */
class SimulatorSource(
    private val sampleRate: Int = 250
) {
    private var phase = 0.0 // Phase within current cardiac cycle [0.0 .. 1.0)
    private var bpm = 72.0
    private var nextArrhythmia: HeartbeatClass? = null
    private var leadsOffMode = false

    fun setTargetBpm(newBpm: Double) {
        this.bpm = newBpm.coerceIn(40.0, 180.0)
    }

    fun injectArrhythmia(rhythm: HeartbeatClass) {
        this.nextArrhythmia = rhythm
    }

    fun setLeadsOff(isOff: Boolean) {
        this.leadsOffMode = isOff
    }

    fun isLeadsOff(): Boolean = leadsOffMode

    /**
     * Generates a batch of N samples (e.g. 15 samples representing 60ms of elapsed time).
     */
    fun generateBatch(count: Int): List<Int> {
        val samples = ArrayList<Int>(count)
        val cycleIncrement = (bpm / 60.0) / sampleRate

        for (i in 0 until count) {
            if (leadsOffMode) {
                // Simulated detached electrode: noise near rail
                val noise = ((sin(phase * 20) * 8).toInt())
                samples.add((1018 + noise).coerceIn(0, 1023))
                phase += cycleIncrement
                continue
            }

            val currentCycle = phase % 1.0
            val activeArrhythmia = nextArrhythmia

            val adcVal = when (activeArrhythmia) {
                HeartbeatClass.PVC -> generatePvcSample(currentCycle)
                HeartbeatClass.APB -> generateApbSample(currentCycle)
                HeartbeatClass.LBBB -> generateLbbbSample(currentCycle)
                HeartbeatClass.RBBB -> generateRbbbSample(currentCycle)
                else -> generateNormalSample(currentCycle)
            }

            samples.add(adcVal)

            phase += cycleIncrement
            if (phase >= 1.0) {
                phase -= 1.0
                // Reset injected single-beat arrhythmia after cycle completion
                if (nextArrhythmia != null) {
                    nextArrhythmia = null
                }
            }
        }

        return samples
    }

    private fun generateNormalSample(t: Double): Int {
        val baseline = 512.0
        // P wave (center 0.16, width 0.035, amp +35)
        val p = 35.0 * exp(-((t - 0.16) * (t - 0.16)) / (2 * 0.035 * 0.035))
        // Q wave (center 0.28, width 0.012, amp -45)
        val q = -45.0 * exp(-((t - 0.28) * (t - 0.28)) / (2 * 0.012 * 0.012))
        // R peak (center 0.32, width 0.018, amp +320)
        val r = 320.0 * exp(-((t - 0.32) * (t - 0.32)) / (2 * 0.018 * 0.018))
        // S wave (center 0.36, width 0.015, amp -85)
        val s = -85.0 * exp(-((t - 0.36) * (t - 0.36)) / (2 * 0.015 * 0.015))
        // T wave (center 0.58, width 0.070, amp +80)
        val tWave = 80.0 * exp(-((t - 0.58) * (t - 0.58)) / (2 * 0.070 * 0.070))

        // Subtle realistic respiratory baseline wander (0.25 Hz)
        val wander = 6.0 * sin(2 * PI * t * 0.25)

        return (baseline + p + q + r + s + tWave + wander).toInt().coerceIn(0, 1023)
    }

    private fun generatePvcSample(t: Double): Int {
        val baseline = 512.0
        // Premature, no P-wave, wide bizarre negative/positive deflection
        val r1 = 360.0 * exp(-((t - 0.24) * (t - 0.24)) / (2 * 0.045 * 0.045))
        val s1 = -240.0 * exp(-((t - 0.33) * (t - 0.33)) / (2 * 0.055 * 0.055))
        val invertedT = -110.0 * exp(-((t - 0.55) * (t - 0.55)) / (2 * 0.090 * 0.090))
        return (baseline + r1 + s1 + invertedT).toInt().coerceIn(0, 1023)
    }

    private fun generateApbSample(t: Double): Int {
        val baseline = 512.0
        // Early P-wave with normal narrow QRS
        val earlyP = 45.0 * exp(-((t - 0.12) * (t - 0.12)) / (2 * 0.025 * 0.025))
        val q = -40.0 * exp(-((t - 0.23) * (t - 0.23)) / (2 * 0.012 * 0.012))
        val r = 290.0 * exp(-((t - 0.26) * (t - 0.26)) / (2 * 0.018 * 0.018))
        val s = -70.0 * exp(-((t - 0.30) * (t - 0.30)) / (2 * 0.015 * 0.015))
        val tWave = 75.0 * exp(-((t - 0.50) * (t - 0.50)) / (2 * 0.065 * 0.065))
        return (baseline + earlyP + q + r + s + tWave).toInt().coerceIn(0, 1023)
    }

    private fun generateLbbbSample(t: Double): Int {
        val baseline = 512.0
        val p = 30.0 * exp(-((t - 0.16) * (t - 0.16)) / (2 * 0.035 * 0.035))
        // Wide notched M-shaped monophasic R
        val r1 = 260.0 * exp(-((t - 0.30) * (t - 0.30)) / (2 * 0.035 * 0.035))
        val r2 = 290.0 * exp(-((t - 0.37) * (t - 0.37)) / (2 * 0.040 * 0.040))
        val broadS = -90.0 * exp(-((t - 0.44) * (t - 0.44)) / (2 * 0.030 * 0.030))
        val invertedT = -70.0 * exp(-((t - 0.62) * (t - 0.62)) / (2 * 0.075 * 0.075))
        return (baseline + p + r1 + r2 + broadS + invertedT).toInt().coerceIn(0, 1023)
    }

    private fun generateRbbbSample(t: Double): Int {
        val baseline = 512.0
        val p = 32.0 * exp(-((t - 0.16) * (t - 0.16)) / (2 * 0.035 * 0.035))
        // rsR' rabbit-ear double notch
        val r1 = 180.0 * exp(-((t - 0.29) * (t - 0.29)) / (2 * 0.015 * 0.015))
        val s = -70.0 * exp(-((t - 0.33) * (t - 0.33)) / (2 * 0.015 * 0.015))
        val rPrime = 270.0 * exp(-((t - 0.38) * (t - 0.38)) / (2 * 0.025 * 0.025))
        val tWave = 65.0 * exp(-((t - 0.58) * (t - 0.58)) / (2 * 0.065 * 0.065))
        return (baseline + p + r1 + s + rPrime + tWave).toInt().coerceIn(0, 1023)
    }
}
