package com.example.network

import com.example.model.DeduplicationMode
import java.util.ArrayDeque
import kotlin.math.min

/**
 * Handles rolling buffer deduplication for ESP8266 web servers.
 * Prevents duplicating previously ingested ECG samples.
 */
class RollingBufferDeduplicator(
    private val historyCapacity: Int = 1000
) {
    private val recentSamplesHistory = ArrayDeque<Int>(historyCapacity)
    private var lastSequenceNumber: Long? = null
    private var duplicateBuffersCount: Long = 0L

    fun getDuplicateBuffersCount(): Long = duplicateBuffersCount

    /**
     * Ingests parsed packet and extracts ONLY genuinely new samples according to [mode].
     */
    fun extractNewSamples(
        packet: ParsedEcgPacket,
        mode: DeduplicationMode
    ): List<Int> {
        val incoming = packet.samples
        if (incoming.isEmpty()) return emptyList()

        when (mode) {
            DeduplicationMode.DISABLED -> {
                // Append everything without deduplication
                for (s in incoming) pushToHistory(s)
                return incoming
            }

            DeduplicationMode.SEQUENCE_ID -> {
                // If packet sequence number is provided and identical to previous, skip entire buffer
                if (packet.sequenceNumber != null) {
                    if (packet.sequenceNumber == lastSequenceNumber) {
                        duplicateBuffersCount++
                        return emptyList()
                    }
                    lastSequenceNumber = packet.sequenceNumber
                }
                for (s in incoming) pushToHistory(s)
                return incoming
            }

            DeduplicationMode.OVERLAP_SUFFIX -> {
                // If sequence number is explicitly present, use it first
                if (packet.sequenceNumber != null && packet.sequenceNumber == lastSequenceNumber) {
                    duplicateBuffersCount++
                    return emptyList()
                }
                if (packet.sequenceNumber != null) {
                    lastSequenceNumber = packet.sequenceNumber
                }

                if (recentSamplesHistory.isEmpty()) {
                    for (s in incoming) pushToHistory(s)
                    return incoming
                }

                val recentList = recentSamplesHistory.toList()
                val maxCheck = min(incoming.size, recentList.size)

                // Search for longest overlap length k from maxCheck down to 1
                var bestOverlap = 0
                for (k in maxCheck downTo 1) {
                    val incomingPrefix = incoming.subList(0, k)
                    val historySuffix = recentList.subList(recentList.size - k, recentList.size)
                    if (incomingPrefix == historySuffix) {
                        bestOverlap = k
                        break
                    }
                }

                if (bestOverlap == incoming.size) {
                    // Whole incoming buffer is an exact duplicate of recently ingested data
                    duplicateBuffersCount++
                    return emptyList()
                }

                val genuinelyNew = if (bestOverlap > 0) {
                    incoming.subList(bestOverlap, incoming.size)
                } else {
                    incoming
                }

                for (s in genuinelyNew) {
                    pushToHistory(s)
                }
                return genuinelyNew
            }
        }
    }

    private fun pushToHistory(sample: Int) {
        if (recentSamplesHistory.size >= historyCapacity) {
            recentSamplesHistory.removeFirst()
        }
        recentSamplesHistory.addLast(sample)
    }

    fun reset() {
        recentSamplesHistory.clear()
        lastSequenceNumber = null
        duplicateBuffersCount = 0L
    }
}
