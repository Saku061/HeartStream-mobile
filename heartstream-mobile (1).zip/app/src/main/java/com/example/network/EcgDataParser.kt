package com.example.network

import org.json.JSONArray
import org.json.JSONObject

data class ParsedEcgPacket(
    val latestValue: Int?,
    val samples: List<Int>,
    val sequenceNumber: Long? = null,
    val timestamp: Long? = null,
    val rawPayload: String
)

/**
 * Robust, resilient JSON & text parser for ESP8266 ECG payloads.
 * Handles:
 * - Example schema: { "latest": 512, "samples": [510, 512, ...] }
 * - Alternative keys: "data", "ecg", "readings", "values", "buffer"
 * - Raw arrays: [510, 512, 515, ...]
 * - Sequence / timestamp tags for deduplication: "seq", "packet_id", "ts"
 * - Comma-delimited plain text: "510,512,515,520"
 */
class EcgDataParser {

    fun parse(rawText: String): ParsedEcgPacket {
        val trimmed = rawText.trim()
        if (trimmed.isEmpty()) {
            return ParsedEcgPacket(null, emptyList(), rawPayload = rawText)
        }

        try {
            if (trimmed.startsWith("{")) {
                val json = JSONObject(trimmed)

                // Sequence / packet number if firmware provides it
                val seq = when {
                    json.has("seq") -> json.optLong("seq")
                    json.has("sequence") -> json.optLong("sequence")
                    json.has("packet_id") -> json.optLong("packet_id")
                    json.has("id") -> json.optLong("id")
                    else -> null
                }

                val ts = when {
                    json.has("timestamp") -> json.optLong("timestamp")
                    json.has("ts") -> json.optLong("ts")
                    json.has("time") -> json.optLong("time")
                    else -> null
                }

                // Latest single ADC value
                val latest = when {
                    json.has("latest") -> json.optInt("latest")
                    json.has("adc") -> json.optInt("adc")
                    json.has("val") -> json.optInt("val")
                    json.has("value") -> json.optInt("value")
                    else -> null
                }

                // Sample array
                val samplesList = mutableListOf<Int>()
                val arrayKey = listOf("samples", "data", "ecg", "readings", "values", "buffer")
                    .firstOrNull { json.has(it) }

                if (arrayKey != null) {
                    val array = json.optJSONArray(arrayKey)
                    if (array != null) {
                        for (i in 0 until array.length()) {
                            samplesList.add(array.getInt(i))
                        }
                    }
                } else if (latest != null) {
                    samplesList.add(latest)
                }

                return ParsedEcgPacket(
                    latestValue = latest ?: samplesList.lastOrNull(),
                    samples = samplesList,
                    sequenceNumber = seq,
                    timestamp = ts,
                    rawPayload = rawText
                )
            } else if (trimmed.startsWith("[")) {
                // Direct JSON Array: [510, 512, ...]
                val array = JSONArray(trimmed)
                val samplesList = mutableListOf<Int>()
                for (i in 0 until array.length()) {
                    samplesList.add(array.getInt(i))
                }
                return ParsedEcgPacket(
                    latestValue = samplesList.lastOrNull(),
                    samples = samplesList,
                    rawPayload = rawText
                )
            } else {
                // Comma-separated or single integers: "510, 512, 515"
                val tokens = trimmed.split(',', '\n', ' ')
                    .mapNotNull { it.trim().toIntOrNull() }
                return ParsedEcgPacket(
                    latestValue = tokens.lastOrNull(),
                    samples = tokens,
                    rawPayload = rawText
                )
            }
        } catch (e: Exception) {
            // Fallback: regex search for integers
            val regex = Regex("\\b\\d{1,4}\\b")
            val numbers = regex.findAll(trimmed).mapNotNull { it.value.toIntOrNull() }.toList()
            return ParsedEcgPacket(
                latestValue = numbers.lastOrNull(),
                samples = numbers,
                rawPayload = rawText
            )
        }
    }
}
