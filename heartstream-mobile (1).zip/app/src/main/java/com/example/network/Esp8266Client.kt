package com.example.network

import com.example.model.AppSettings
import com.example.model.ConnectionInfo
import com.example.model.ConnectionStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Manages HTTP Polling and WebSocket streaming connections to the ESP8266 NodeMCU server.
 */
class Esp8266Client(
    private val scope: CoroutineScope,
    private val parser: EcgDataParser = EcgDataParser()
) {
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .writeTimeout(3, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val _connectionInfo = MutableStateFlow(ConnectionInfo())
    val connectionInfo: StateFlow<ConnectionInfo> = _connectionInfo.asStateFlow()

    private val _packetFlow = MutableSharedFlow<ParsedEcgPacket>(extraBufferCapacity = 64)
    val packetFlow: SharedFlow<ParsedEcgPacket> = _packetFlow.asSharedFlow()

    private var pollingJob: Job? = null
    private var webSocket: WebSocket? = null
    private var isRunning = false

    fun start(settings: AppSettings) {
        stop()
        isRunning = true

        if (settings.isWebSocket) {
            connectWebSocket(settings)
        } else {
            startHttpPolling(settings)
        }
    }

    fun stop() {
        isRunning = false
        pollingJob?.cancel()
        pollingJob = null
        try {
            webSocket?.close(1000, "User disconnected")
        } catch (_: Exception) {}
        webSocket = null
        _connectionInfo.value = ConnectionInfo(
            status = ConnectionStatus.DISCONNECTED,
            message = "Monitoring stopped by user"
        )
    }

    private fun startHttpPolling(settings: AppSettings) {
        val url = buildUrl(settings, isWs = false)
        _connectionInfo.value = ConnectionInfo(
            status = ConnectionStatus.CONNECTING,
            host = settings.espHost,
            message = "Connecting to $url..."
        )

        pollingJob = scope.launch(Dispatchers.IO) {
            var consecutiveFailures = 0

            while (isActive && isRunning) {
                val startNs = System.nanoTime()
                try {
                    val request = Request.Builder()
                        .url(url)
                        .header("Accept", "application/json, text/plain")
                        .build()

                    val response: Response = okHttpClient.newCall(request).execute()
                    val latencyMs = (System.nanoTime() - startNs) / 1_000_000

                    if (response.isSuccessful) {
                        consecutiveFailures = 0
                        val bodyString = response.body?.string() ?: ""
                        response.close()

                        val parsed = parser.parse(bodyString)
                        _packetFlow.tryEmit(parsed)

                        _connectionInfo.value = ConnectionInfo(
                            status = ConnectionStatus.CONNECTED,
                            host = settings.espHost,
                            latencyMs = latencyMs,
                            message = "Connected to ${settings.espHost}"
                        )
                    } else {
                        response.close()
                        consecutiveFailures++
                        handleFailure(consecutiveFailures, settings.espHost, "HTTP ${response.code}")
                    }
                } catch (e: Exception) {
                    if (e is CancellationException) throw e
                    consecutiveFailures++
                    handleFailure(consecutiveFailures, settings.espHost, e.localizedMessage ?: "Connection error")
                }

                // Dynamic throttle based on consecutive failures (reconnect backoff)
                val delayTime = if (consecutiveFailures > 0) {
                    (settings.pollingIntervalMs * (1 + consecutiveFailures)).coerceAtMost(2500L)
                } else {
                    settings.pollingIntervalMs
                }
                delay(delayTime)
            }
        }
    }

    private fun handleFailure(failures: Int, host: String, reason: String) {
        if (failures >= 2) {
            _connectionInfo.value = ConnectionInfo(
                status = ConnectionStatus.RECONNECTING,
                host = host,
                message = "Reconnecting ($failures)... $reason"
            )
        }
    }

    private fun connectWebSocket(settings: AppSettings) {
        val wsUrl = buildUrl(settings, isWs = true)
        _connectionInfo.value = ConnectionInfo(
            status = ConnectionStatus.CONNECTING,
            host = settings.espHost,
            message = "Connecting WebSocket $wsUrl..."
        )

        val request = Request.Builder().url(wsUrl).build()
        webSocket = okHttpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                _connectionInfo.value = ConnectionInfo(
                    status = ConnectionStatus.CONNECTED,
                    host = settings.espHost,
                    message = "WebSocket Connected"
                )
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val parsed = parser.parse(text)
                _packetFlow.tryEmit(parsed)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (!isRunning) return
                _connectionInfo.value = ConnectionInfo(
                    status = ConnectionStatus.RECONNECTING,
                    host = settings.espHost,
                    message = "WS Disconnected: ${t.localizedMessage}"
                )
                // Schedule reconnect
                scope.launch {
                    delay(2000L)
                    if (isRunning) connectWebSocket(settings)
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (!isRunning) return
                _connectionInfo.value = ConnectionInfo(
                    status = ConnectionStatus.DISCONNECTED,
                    host = settings.espHost,
                    message = "WS Closed ($code)"
                )
            }
        })
    }

    private fun buildUrl(settings: AppSettings, isWs: Boolean): String {
        val scheme = if (isWs) "ws" else "http"
        val path = if (settings.endpointPath.startsWith("/")) settings.endpointPath else "/${settings.endpointPath}"
        return if (settings.espPort == 80 && !isWs) {
            "$scheme://${settings.espHost}$path"
        } else {
            "$scheme://${settings.espHost}:${settings.espPort}$path"
        }
    }
}
