package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val HeartStreamColorScheme = darkColorScheme(
    primary = EcgGreen,
    onPrimary = Color(0xFF003815),
    primaryContainer = Color(0xFF005322),
    onPrimaryContainer = Color(0xFF86FFA5),
    secondary = TelemetryCyan,
    onSecondary = Color(0xFF00363D),
    secondaryContainer = Color(0xFF004E58),
    onSecondaryContainer = Color(0xFF97F0FF),
    tertiary = HeartPulseRed,
    onTertiary = Color(0xFF5F001E),
    tertiaryContainer = Color(0xFF8B002F),
    onTertiaryContainer = Color(0xFFFFD9DF),
    background = MonitorBg,
    onBackground = TextPrimary,
    surface = MonitorSurface,
    onSurface = TextPrimary,
    surfaceVariant = MonitorSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = MonitorCardBorder,
    outlineVariant = Color(0xFF263C52),
    error = DisconnectedRed,
    onError = Color(0xFF68000A)
)

@Composable
fun HeartStreamTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = HeartStreamColorScheme,
        typography = Typography,
        content = content
    )
}
