package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SignalQuality
import com.example.ui.theme.QualityFair
import com.example.ui.theme.QualityGood
import com.example.ui.theme.QualityLeadsOff
import com.example.ui.theme.QualityPoor

@Composable
fun SignalQualityBadge(
    quality: SignalQuality,
    modifier: Modifier = Modifier
) {
    val (color, text) = when (quality) {
        SignalQuality.EXCELLENT -> QualityGood to "SIGNAL: OPTIMAL"
        SignalQuality.GOOD -> QualityGood to "SIGNAL: GOOD"
        SignalQuality.FAIR -> QualityFair to "SIGNAL: FAIR"
        SignalQuality.POOR -> QualityPoor to "SIGNAL: NOISY"
        SignalQuality.LEADS_OFF -> QualityLeadsOff to "LEADS DETACHED"
    }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag("signal_quality_badge"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = text,
            color = color,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }
}
