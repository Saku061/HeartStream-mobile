package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectionStatus
import com.example.model.HeartbeatClass
import com.example.model.SignalQuality
import com.example.ui.EcgViewModel
import com.example.ui.components.AiPredictionCard
import com.example.ui.components.EcgWaveformCanvas
import com.example.ui.components.HeartRateDisplay
import com.example.ui.components.SignalQualityBadge
import com.example.ui.theme.DisconnectedRed
import com.example.ui.theme.EcgGreen
import com.example.ui.theme.HeartPulseRed
import com.example.ui.theme.MonitorBg
import com.example.ui.theme.MonitorCardBorder
import com.example.ui.theme.MonitorSurface
import com.example.ui.theme.QualityFair
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: EcgViewModel,
    modifier: Modifier = Modifier
) {
    val connectionInfo by viewModel.connectionInfo.collectAsState()
    val waveformPoints by viewModel.waveformPoints.collectAsState()
    val isMonitoring by viewModel.isMonitoringActive.collectAsState()
    val latestAdc by viewModel.latestAdc.collectAsState()
    val latestMv by viewModel.latestMillivolts.collectAsState()
    val bpm by viewModel.bpm.collectAsState()
    val signalQuality by viewModel.signalQuality.collectAsState()
    val lastClassification by viewModel.lastClassification.collectAsState()
    val elapsedSec by viewModel.elapsedMonitoringSeconds.collectAsState()
    val isRecording by viewModel.isRecordingSession.collectAsState()
    val recordingDuration by viewModel.recordingDurationSeconds.collectAsState()
    val pulseTrigger by viewModel.heartBeatPulseTrigger.collectAsState()
    val settings by viewModel.settings.collectAsState()

    val isSignalAdequate = signalQuality != SignalQuality.LEADS_OFF && signalQuality != SignalQuality.POOR

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MonitorBg)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .testTag("dashboard_screen")
    ) {
        // Top Status Header: Connection State & Elapsed Time
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Connection Pill
            val (statusColor, statusText) = when (connectionInfo.status) {
                ConnectionStatus.CONNECTED -> EcgGreen to if (settings.simulationMode) "SIMULATION ACTIVE" else "CONNECTED"
                ConnectionStatus.CONNECTING -> TelemetryCyan to "CONNECTING..."
                ConnectionStatus.RECONNECTING -> WarningAmber to "RECONNECTING"
                ConnectionStatus.DISCONNECTED -> TextMuted to "DISCONNECTED"
                ConnectionStatus.ERROR -> DisconnectedRed to "OFFLINE"
            }

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(statusColor.copy(alpha = 0.12f))
                    .border(1.dp, statusColor.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(statusColor)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = statusText,
                    color = statusColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Elapsed Monitoring Timer
            val elapsedFormatted = String.format(
                Locale.US,
                "%02d:%02d",
                elapsedSec / 60,
                elapsedSec % 60
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "TIME: ",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = elapsedFormatted,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Live ECG Waveform
        EcgWaveformCanvas(
            points = waveformPoints,
            sweepSpeedMmPerSec = settings.sweepSpeedMmPerSec,
            isMonitoring = isMonitoring
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Toolbar: Controls & Sweep Speeds
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Start/Pause Button
            Button(
                onClick = { viewModel.toggleMonitoring() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isMonitoring) Color(0xFF233549) else EcgGreen,
                    contentColor = if (isMonitoring) TextPrimary else Color(0xFF003815)
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("toggle_monitoring_button")
            ) {
                Icon(
                    imageVector = if (isMonitoring) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isMonitoring) "Pause" else "Start",
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isMonitoring) "PAUSE" else "MONITOR",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            // Record Session Button
            OutlinedButton(
                onClick = {
                    if (isRecording) {
                        viewModel.stopAndSaveRecordingSession()
                    } else {
                        viewModel.startRecordingSession()
                    }
                },
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = if (isRecording) HeartPulseRed else TextPrimary
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("record_session_button")
            ) {
                Icon(
                    imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                    contentDescription = "Record",
                    tint = if (isRecording) HeartPulseRed else DisconnectedRed,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isRecording) "REC ${recordingDuration}s" else "REC",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            // Clear & Reconnect Icons
            Row {
                IconButton(
                    onClick = { viewModel.clearWaveform() },
                    modifier = Modifier.testTag("clear_waveform_button")
                ) {
                    Text("CLR", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                IconButton(
                    onClick = { viewModel.reconnect() },
                    modifier = Modifier.testTag("reconnect_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reconnect",
                        tint = TelemetryCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Sweep speed selector chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SWEEP SPEED:",
                color = TextSecondary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(12.5f, 25f, 50f).forEach { speed ->
                    val isSelected = settings.sweepSpeedMmPerSec == speed
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.updateSettings(settings.copy(sweepSpeedMmPerSec = speed)) },
                        label = {
                            Text(
                                text = "${speed.toInt()} mm/s",
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EcgGreen.copy(alpha = 0.2f),
                            selectedLabelColor = EcgGreen
                        ),
                        modifier = Modifier.height(30.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Heart Rate & Signal Quality metrics
        HeartRateDisplay(
            bpm = bpm,
            latestAdc = latestAdc,
            latestMv = latestMv,
            pulseTrigger = pulseTrigger,
            isSignalAdequate = isSignalAdequate
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Signal Quality Badge row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SignalQualityBadge(quality = signalQuality)
            Text(
                text = "Host: ${settings.espHost}",
                color = TextMuted,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // AI Arrhythmia Classification Card
        AiPredictionCard(
            result = lastClassification,
            signalQuality = signalQuality,
            isMonitoring = isMonitoring
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Arrhythmia Testing Drawer (allows testing MIT-BIH beats on the fly!)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MonitorSurface)
                .border(1.dp, MonitorCardBorder, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "HARDWARE SIMULATION & TEST INJECTOR",
                    color = TextPrimary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = if (settings.simulationMode) "SIM ON" else "SIM OFF",
                    color = if (settings.simulationMode) EcgGreen else TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable {
                        viewModel.toggleSimulationMode(!settings.simulationMode)
                    }
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Tap any rhythm below to inject it into the next cardiac cycle for real-time model evaluation:",
                color = TextSecondary,
                fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    HeartbeatClass.NORMAL,
                    HeartbeatClass.PVC,
                    HeartbeatClass.APB,
                    HeartbeatClass.LBBB,
                    HeartbeatClass.RBBB
                ).forEach { rhythm ->
                    OutlinedButton(
                        onClick = {
                            if (!settings.simulationMode) {
                                viewModel.toggleSimulationMode(true)
                            }
                            viewModel.injectArrhythmia(rhythm)
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 2.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = rhythm.code,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (rhythm) {
                                HeartbeatClass.NORMAL -> EcgGreen
                                HeartbeatClass.PVC -> HeartPulseRed
                                HeartbeatClass.APB -> WarningAmber
                                HeartbeatClass.LBBB, HeartbeatClass.RBBB -> TelemetryCyan
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Safety & Validation Disclaimer (Mandatory)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Medical Disclaimer",
                tint = TextMuted,
                modifier = Modifier
                    .size(16.dp)
                    .padding(top = 2.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Educational ECG Prototype. Not a medical device. Arrhythmia predictions require independent validation and clinical interpretation. Accuracy is subject to electrode placement, skin impedance and sensor noise.",
                color = TextMuted,
                fontSize = 10.sp,
                lineHeight = 14.sp
            )
        }
    }
}
