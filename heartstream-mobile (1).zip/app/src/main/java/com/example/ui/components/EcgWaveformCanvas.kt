package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EcgGreen
import com.example.ui.theme.EcgGreenBright
import com.example.ui.theme.EcgGridMajor
import com.example.ui.theme.EcgGridMinor
import com.example.ui.theme.MonitorBg
import com.example.ui.theme.MonitorCardBorder

/**
 * Authentic medical ECG monitor canvas:
 * - Real-time scrolling cardiac trace with phosphor persistence glow
 * - Standard medical 1mm minor grid and 5mm major grid
 * - 1 mV = 10 mm standard calibration pulse indicator
 * - Smooth 60fps rendering without UI thread hitching
 */
@Composable
fun EcgWaveformCanvas(
    points: List<Float>,
    sweepSpeedMmPerSec: Float,
    isMonitoring: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(240.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MonitorBg)
            .border(1.dp, MonitorCardBorder, RoundedCornerShape(12.dp))
            .testTag("ecg_waveform_canvas")
    ) {
        Canvas(
            modifier = Modifier.fillMaxSize()
        ) {
            val width = size.width
            val height = size.height
            val midY = height / 2f

            // 1. Draw standard ECG grid
            // Grid spacing: minor = ~12dp (~1mm equivalent), major = 5 * minor (~5mm equivalent)
            val minorStep = 14.dp.toPx()
            val majorStep = minorStep * 5f

            // Vertical minor grid lines (0.04s equivalent)
            var x = 0f
            while (x <= width) {
                val isMajor = (x % majorStep) < minorStep * 0.5f || ((majorStep - (x % majorStep)) < minorStep * 0.5f)
                drawLine(
                    color = if (isMajor) EcgGridMajor else EcgGridMinor,
                    start = Offset(x, 0f),
                    end = Offset(x, height),
                    strokeWidth = if (isMajor) 1.2f else 0.6f
                )
                x += minorStep
            }

            // Horizontal minor grid lines (0.1mV equivalent)
            var y = 0f
            while (y <= height) {
                val isMajor = (y % majorStep) < minorStep * 0.5f || ((majorStep - (y % majorStep)) < minorStep * 0.5f)
                drawLine(
                    color = if (isMajor) EcgGridMajor else EcgGridMinor,
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = if (isMajor) 1.2f else 0.6f
                )
                y += minorStep
            }

            // Central isoelectric baseline (0 mV)
            drawLine(
                color = EcgGridMajor.copy(alpha = 0.45f),
                start = Offset(0f, midY),
                end = Offset(width, midY),
                strokeWidth = 1.5f
            )

            // 2. Draw 1 mV standard calibration pulse mark on left edge
            // 1 mV pulse is typically 5mm high (major grid step)
            val calWidth = 24.dp.toPx()
            val calHeight = majorStep // 1 mV calibration pulse
            val calX = 12.dp.toPx()
            val calPath = Path().apply {
                moveTo(calX, midY)
                lineTo(calX + calWidth * 0.25f, midY)
                lineTo(calX + calWidth * 0.25f, midY - calHeight)
                lineTo(calX + calWidth * 0.75f, midY - calHeight)
                lineTo(calX + calWidth * 0.75f, midY)
                lineTo(calX + calWidth, midY)
            }
            drawPath(
                path = calPath,
                color = EcgGreen.copy(alpha = 0.5f),
                style = Stroke(width = 1.5f)
            )

            // 3. Draw ECG signal trace
            if (points.isNotEmpty()) {
                val numPoints = points.size
                val stepX = width / (numPoints - 1).coerceAtLeast(1)

                // Scaling: 1 mV = calHeight pixels
                val mvScale = calHeight

                val tracePath = Path()
                var first = true

                for (i in 0 until numPoints) {
                    val px = i * stepX
                    // Clamp to visible canvas height with padding
                    val py = (midY - points[i] * mvScale).coerceIn(4f, height - 4f)

                    if (first) {
                        tracePath.moveTo(px, py)
                        first = false
                    } else {
                        tracePath.lineTo(px, py)
                    }
                }

                // Draw outer phosphor bloom / glow
                drawPath(
                    path = tracePath,
                    color = EcgGreenBright.copy(alpha = 0.25f),
                    style = Stroke(
                        width = 4.5f,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )

                // Draw sharp crisp phosphor core
                drawPath(
                    path = tracePath,
                    color = EcgGreenBright,
                    style = Stroke(
                        width = 2.0f,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )

                // Draw current leading edge sweep dot
                val lastIdx = numPoints - 1
                val lastX = lastIdx * stepX
                val lastY = (midY - points[lastIdx] * mvScale).coerceIn(4f, height - 4f)

                if (isMonitoring) {
                    drawCircle(
                        color = Color.White,
                        radius = 4.5f,
                        center = Offset(lastX, lastY)
                    )
                    drawCircle(
                        color = EcgGreenBright.copy(alpha = 0.5f),
                        radius = 9f,
                        center = Offset(lastX, lastY)
                    )
                }
            }
        }

        // Overlay status indicators in corners
        Text(
            text = "LEAD II  •  ${sweepSpeedMmPerSec.toInt()} mm/s  •  10 mm/mV",
            color = EcgGreen.copy(alpha = 0.8f),
            fontSize = 11.sp,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp)
        )

        Text(
            text = if (isMonitoring) "LIVE SWEEP" else "PAUSED",
            color = if (isMonitoring) EcgGreenBright else Color(0xFFFFB300),
            fontSize = 10.sp,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp)
        )
    }
}
