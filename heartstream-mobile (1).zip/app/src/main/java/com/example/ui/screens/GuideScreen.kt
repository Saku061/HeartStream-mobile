package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.NetworkWifi
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EcgGreen
import com.example.ui.theme.HeartPulseRed
import com.example.ui.theme.MonitorBg
import com.example.ui.theme.MonitorCardBorder
import com.example.ui.theme.MonitorSurface
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber

@Composable
fun GuideScreen(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MonitorBg)
            .verticalScroll(rememberScrollState())
            .padding(14.dp)
            .testTag("guide_screen")
    ) {
        Text(
            text = "HARDWARE & AI DEPLOYMENT GUIDE",
            color = TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        // 1. ESP8266 & Wi-Fi Connection
        GuideSectionCard(
            title = "1. ESP8266 Wi-Fi Access Point Connection",
            icon = Icons.Default.NetworkWifi,
            iconTint = TelemetryCyan
        ) {
            Text(
                text = "1. Power on your ESP8266 NodeMCU connected to the AD8232 sensor.\n" +
                        "2. On your phone, open Settings > Wi-Fi and connect to the ESP8266's access point (default: 'ESP8266-ECG' or custom SSID).\n" +
                        "3. CRITICAL Android Warning: When Android displays 'This Wi-Fi network has no internet connection. Stay connected?', tap 'YES / STAY CONNECTED'. Do NOT switch back to cellular data, otherwise requests to 192.168.4.1 will be routed through mobile data and fail.\n" +
                        "4. The app includes cleartext HTTP permissions configured in Android Network Security to connect directly to http://192.168.4.1/data.",
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 2. AD8232 Sensor & Lead Placement
        GuideSectionCard(
            title = "2. AD8232 Electrode Placement (Einthoven Lead II)",
            icon = Icons.Default.Sensors,
            iconTint = EcgGreen
        ) {
            Text(
                text = "• Red Pad (RA - Right Arm): Right side of the chest below the right clavicle.\n" +
                        "• Yellow Pad (LA - Left Arm): Left side of the chest below the left clavicle.\n" +
                        "• Green Pad (RL - Right Leg): Lower right abdomen or rib (acts as reference ground).\n\n" +
                        "Leads-Off Detection: If pads detach, the AD8232 outputs 0 or 1023 ADC counts. HeartStream detects this immediately and halts BPM and AI classification until stable contact is restored.",
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 3. AI Model Conversion Script
        GuideSectionCard(
            title = "3. PyTorch to ONNX Model Conversion",
            icon = Icons.Default.Code,
            iconTint = WarningAmber
        ) {
            Text(
                text = "To convert the PyTorch 'best_model.pth' or 'final_model.pth' from the HeartStream repository into an ONNX mobile-compatible model, run this Python script on your computer:",
                color = TextSecondary,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF03070A))
                    .border(1.dp, MonitorCardBorder, RoundedCornerShape(8.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "# convert_heartstream_model.py\n" +
                            "import torch\n" +
                            "from src.models.ecgnet import ECGNet\n\n" +
                            "model = ECGNet(num_classes=5)\n" +
                            "model.load_state_dict(torch.load('best_model.pth', map_location='cpu'))\n" +
                            "model.eval()\n\n" +
                            "# Dummy input: [batch=1, channel=1, length=250]\n" +
                            "dummy_input = torch.randn(1, 1, 250)\n" +
                            "torch.onnx.export(\n" +
                            "    model, dummy_input,\n" +
                            "    'heartstream_ecgnet.onnx',\n" +
                            "    input_names=['input_ecg'],\n" +
                            "    output_names=['probabilities'],\n" +
                            "    opset_version=13\n" +
                            ")\n" +
                            "print('ONNX model exported to heartstream_ecgnet.onnx!')",
                    color = EcgGreen,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Copy 'heartstream_ecgnet.onnx' to your phone and import it in the Diagnostics tab, or use the high-performance embedded 1D-CNN engine built directly into the app.",
                color = TextSecondary,
                fontSize = 12.sp
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 4. Troubleshooting Steps
        GuideSectionCard(
            title = "4. Troubleshooting Connection & Data",
            icon = Icons.Default.HelpOutline,
            iconTint = HeartPulseRed
        ) {
            Text(
                text = "• App shows 'Reconnecting': Check if your phone's Wi-Fi dropped connection to ESP8266 or if the ESP8266 IP changed. You can change host address in Settings.\n\n" +
                        "• Duplicate ECG Samples: The firmware may return rolling buffers. HeartStream's 'Rolling Buffer Suffix Matching' automatically detects duplicate windows and only appends new points.\n\n" +
                        "• Flatline or Rail Saturation: Check sensor cable connection to AD8232 3.5mm jack.\n\n" +
                        "• AI Predictions Show 'Signal Insufficient': AI classification is safely paused during poor signal quality or lead detachment.",
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
private fun GuideSectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MonitorSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MonitorCardBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}
