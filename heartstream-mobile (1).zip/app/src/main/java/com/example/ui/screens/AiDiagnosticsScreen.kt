package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HeartbeatClass
import com.example.ui.EcgViewModel
import com.example.ui.theme.EcgGreen
import com.example.ui.theme.HeartPulseRed
import com.example.ui.theme.MonitorBg
import com.example.ui.theme.MonitorCardBorder
import com.example.ui.theme.MonitorSurface
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AiDiagnosticsScreen(
    viewModel: EcgViewModel,
    modifier: Modifier = Modifier
) {
    val diagnostics by viewModel.diagnostics.collectAsState()
    val modelStatus by viewModel.modelManager.modelStatusText.collectAsState()
    val isExternalLoaded by viewModel.modelManager.isExternalModelLoaded.collectAsState()
    val recentArrhythmias by viewModel.recentArrhythmias.collectAsState()

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            viewModel.loadCustomOnnxModel(uri)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MonitorBg)
            .verticalScroll(rememberScrollState())
            .padding(14.dp)
            .testTag("ai_diagnostics_screen")
    ) {
        // Section: AI Model Engine
        Text(
            text = "AI INFERENCE ENGINE",
            color = TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MonitorSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MonitorCardBorder),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = "Model",
                            tint = TelemetryCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Model Architecture: ECGNet 1D-CNN",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Status: $modelStatus",
                    color = EcgGreen,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Trained on MIT-BIH Arrhythmia Database (Records 100-124, 200-234) with 250-sample normalized beat windows at 250 Hz. Inference is computed purely on-device without cloud network latency or data transmission.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { filePickerLauncher.launch("*/*") },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1E3146),
                            contentColor = TelemetryCyan
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("import_onnx_button")
                    ) {
                        Icon(Icons.Default.FileOpen, contentDescription = "Load", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("IMPORT .ONNX MODEL", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    if (isExternalLoaded) {
                        OutlinedButton(
                            onClick = { viewModel.modelManager.useEmbeddedModel() },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("RESET TO EMBEDDED", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Section: Real-Time Telemetry & Diagnostics
        Text(
            text = "REAL-TIME DIAGNOSTICS & TELEMETRY",
            color = TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MonitorSurface)
                .border(1.dp, MonitorCardBorder, RoundedCornerShape(12.dp))
                .padding(14.dp)
        ) {
            DiagnosticMetricRow(
                icon = Icons.Default.Speed,
                label = "Received Sample Rate",
                value = String.format(Locale.US, "%.1f Hz", diagnostics.receivedSamplesPerSec),
                detail = "Nominal: 250 Hz",
                color = if (diagnostics.receivedSamplesPerSec > 200f) EcgGreen else WarningAmber
            )

            DiagnosticMetricRow(
                icon = Icons.Default.Speed,
                label = "Network Round-Trip (RTT)",
                value = "${diagnostics.latencyRttMs} ms",
                detail = "HTTP Polling Latency",
                color = if (diagnostics.latencyRttMs < 120L) EcgGreen else WarningAmber
            )

            DiagnosticMetricRow(
                icon = Icons.Default.Memory,
                label = "DSP Processing Latency",
                value = String.format(Locale.US, "%.2f ms", diagnostics.dspProcessingTimeMs),
                detail = "IIR Filter + Pan-Tompkins",
                color = TelemetryCyan
            )

            DiagnosticMetricRow(
                icon = Icons.Default.Psychology,
                label = "AI Inference Latency",
                value = String.format(Locale.US, "%.2f ms", diagnostics.aiInferenceTimeMs),
                detail = "1D-CNN On-Device Execution",
                color = TelemetryCyan
            )

            DiagnosticMetricRow(
                icon = Icons.Default.Analytics,
                label = "Duplicate Buffers Filtered",
                value = "${diagnostics.duplicateBuffersSuppressed}",
                detail = "Rolling buffer deduplication",
                color = TextSecondary
            )

            DiagnosticMetricRow(
                icon = Icons.Default.Analytics,
                label = "Circular AI Buffer",
                value = "${diagnostics.bufferSize} samples",
                detail = "Max capacity: 600 samples",
                color = TextSecondary
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Section: Raw ESP8266 Payload Inspector
        Text(
            text = "RAW ESP8266 RESPONSE INSPECTOR",
            color = TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF03070A))
                .border(1.dp, MonitorCardBorder, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = "Payload",
                        tint = EcgGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LAST INCOMING JSON PAYLOAD",
                        color = EcgGreen,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                val lastTime = if (diagnostics.lastReceivedTimestamp > 0L) {
                    SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(diagnostics.lastReceivedTimestamp))
                } else "N/A"
                Text(text = "Received: $lastTime", color = TextMuted, fontSize = 10.sp)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = diagnostics.lastRawPayload.take(280) + if (diagnostics.lastRawPayload.length > 280) "..." else "",
                color = TextPrimary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 15.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Section: Arrhythmia Classes Reference Guide
        Text(
            text = "MIT-BIH ARRHYTHMIA CLASSES",
            color = TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MonitorSurface)
                .border(1.dp, MonitorCardBorder, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            HeartbeatClass.entries.forEach { cls ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    val badgeColor = when (cls) {
                        HeartbeatClass.NORMAL -> EcgGreen
                        HeartbeatClass.PVC -> HeartPulseRed
                        HeartbeatClass.APB -> WarningAmber
                        HeartbeatClass.LBBB, HeartbeatClass.RBBB -> TelemetryCyan
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(badgeColor.copy(alpha = 0.15f))
                            .border(1.dp, badgeColor.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = cls.code,
                            color = badgeColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = cls.title,
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = cls.shortDescription,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
private fun DiagnosticMetricRow(
    icon: ImageVector,
    label: String,
    value: String,
    detail: String,
    color: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = TextSecondary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(text = label, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Text(text = detail, color = TextMuted, fontSize = 10.sp)
            }
        }
        Text(
            text = value,
            color = color,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}
