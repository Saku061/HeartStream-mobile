package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.EmbeddedEcgNetClassifier
import com.example.ai.ModelManager
import com.example.data.EcgDatabase
import com.example.data.SettingsRepository
import com.example.dsp.BpmCalculator
import com.example.dsp.EcgFilter
import com.example.dsp.RPeakDetector
import com.example.dsp.SignalQualityEstimator
import com.example.model.AppSettings
import com.example.model.ClassificationResult
import com.example.model.ConnectionInfo
import com.example.model.ConnectionStatus
import com.example.model.DiagnosticsInfo
import com.example.model.EcgSample
import com.example.model.EcgSession
import com.example.model.HeartbeatClass
import com.example.model.SignalQuality
import com.example.network.Esp8266Client
import com.example.network.ParsedEcgPacket
import com.example.network.RollingBufferDeduplicator
import com.example.network.SimulatorSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.ArrayDeque

class EcgViewModel(application: Application) : AndroidViewModel(application) {

    private val db = EcgDatabase.getDatabase(application)
    private val sessionDao = db.ecgSessionDao()
    private val settingsRepo = SettingsRepository(application)
    val modelManager = ModelManager(application)

    val settings: StateFlow<AppSettings> = settingsRepo.settings
    val allSessions: StateFlow<List<EcgSession>> = sessionDao.getAllSessions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Network & Hardware
    private val espClient = Esp8266Client(viewModelScope)
    val connectionInfo: StateFlow<ConnectionInfo> = espClient.connectionInfo
    private val deduplicator = RollingBufferDeduplicator(1200)
    private val simulator = SimulatorSource(250)

    // DSP chain
    private val ecgFilter = EcgFilter()
    private val rPeakDetector = RPeakDetector()
    private val bpmCalculator = BpmCalculator()
    private val signalQualityEstimator = SignalQualityEstimator()

    // Circular sample history for AI classification window (500 samples)
    private val aiSampleHistory = ArrayDeque<Float>(600)

    // Waveform display buffer (stores 750 points ~ 3.0s window for smooth 60fps scrolling)
    private val displayBufferSize = 750
    private val displayPoints = FloatArray(displayBufferSize)
    private var displayHead = 0

    // UI state flows
    private val _waveformPoints = MutableStateFlow<List<Float>>(emptyList())
    val waveformPoints: StateFlow<List<Float>> = _waveformPoints.asStateFlow()

    private val _latestAdc = MutableStateFlow(512)
    val latestAdc: StateFlow<Int> = _latestAdc.asStateFlow()

    private val _latestMillivolts = MutableStateFlow(0f)
    val latestMillivolts: StateFlow<Float> = _latestMillivolts.asStateFlow()

    private val _bpm = MutableStateFlow<Int?>(null)
    val bpm: StateFlow<Int?> = _bpm.asStateFlow()

    private val _signalQuality = MutableStateFlow(SignalQuality.GOOD)
    val signalQuality: StateFlow<SignalQuality> = _signalQuality.asStateFlow()

    private val _lastClassification = MutableStateFlow<ClassificationResult?>(null)
    val lastClassification: StateFlow<ClassificationResult?> = _lastClassification.asStateFlow()

    private val _recentArrhythmias = MutableStateFlow<List<ClassificationResult>>(emptyList())
    val recentArrhythmias: StateFlow<List<ClassificationResult>> = _recentArrhythmias.asStateFlow()

    private val _diagnostics = MutableStateFlow(DiagnosticsInfo())
    val diagnostics: StateFlow<DiagnosticsInfo> = _diagnostics.asStateFlow()

    private val _isMonitoringActive = MutableStateFlow(false)
    val isMonitoringActive: StateFlow<Boolean> = _isMonitoringActive.asStateFlow()

    private val _elapsedMonitoringSeconds = MutableStateFlow(0L)
    val elapsedMonitoringSeconds: StateFlow<Long> = _elapsedMonitoringSeconds.asStateFlow()

    private val _isRecordingSession = MutableStateFlow(false)
    val isRecordingSession: StateFlow<Boolean> = _isRecordingSession.asStateFlow()

    private val _recordingDurationSeconds = MutableStateFlow(0L)
    val recordingDurationSeconds: StateFlow<Long> = _recordingDurationSeconds.asStateFlow()

    private val _heartBeatPulseTrigger = MutableStateFlow(0L)
    val heartBeatPulseTrigger: StateFlow<Long> = _heartBeatPulseTrigger.asStateFlow()

    // Recording session state
    private var sessionStartTimeMs = 0L
    private val recordedBpmList = mutableListOf<Int>()
    private var totalSessionBeats = 0
    private var abnormalSessionBeats = 0
    private val recordedSnapshots = mutableListOf<Float>()

    private var simulationJob: Job? = null
    private var elapsedTimerJob: Job? = null
    private var throughputTimerJob: Job? = null
    private var samplesReceivedInLastSec = 0
    private var lastRawJsonPayload = "{}"

    // Vibrator for haptic R-peak pulse
    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = application.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vm?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            application.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    init {
        // Collect live incoming packets from ESP8266
        viewModelScope.launch {
            espClient.packetFlow.collect { packet ->
                if (_isMonitoringActive.value) {
                    processIncomingPacket(packet)
                }
            }
        }

        // Apply initial config to DSP
        applySettingsToDsp(settings.value)

        // Launch throughput statistics loop (calculates true received Hz)
        throughputTimerJob = viewModelScope.launch {
            while (isActive) {
                delay(1000L)
                val currentRate = samplesReceivedInLastSec.toFloat()
                samplesReceivedInLastSec = 0

                _diagnostics.value = _diagnostics.value.copy(
                    receivedSamplesPerSec = currentRate,
                    bufferSize = aiSampleHistory.size,
                    duplicateBuffersSuppressed = deduplicator.getDuplicateBuffersCount(),
                    latencyRttMs = espClient.connectionInfo.value.latencyMs,
                    lastRawPayload = lastRawJsonPayload
                )
            }
        }
    }

    fun startMonitoring() {
        if (_isMonitoringActive.value) return
        _isMonitoringActive.value = true

        applySettingsToDsp(settings.value)

        if (settings.value.simulationMode) {
            startSimulationSource()
        } else {
            espClient.start(settings.value)
        }

        startElapsedTimer()
    }

    fun stopMonitoring() {
        _isMonitoringActive.value = false
        espClient.stop()
        simulationJob?.cancel()
        simulationJob = null
        elapsedTimerJob?.cancel()
        elapsedTimerJob = null
    }

    fun toggleMonitoring() {
        if (_isMonitoringActive.value) {
            stopMonitoring()
        } else {
            startMonitoring()
        }
    }

    fun clearWaveform() {
        displayPoints.fill(0f)
        displayHead = 0
        _waveformPoints.value = emptyList()
        aiSampleHistory.clear()
        _lastClassification.value = null
        _recentArrhythmias.value = emptyList()
        bpmCalculator.reset()
        rPeakDetector.reset()
        ecgFilter.reset()
        _bpm.value = null
    }

    fun reconnect() {
        stopMonitoring()
        clearWaveform()
        startMonitoring()
    }

    fun toggleSimulationMode(enabled: Boolean) {
        val updated = settings.value.copy(simulationMode = enabled)
        updateSettings(updated)
        if (_isMonitoringActive.value) {
            reconnect()
        }
    }

    fun injectArrhythmia(rhythm: HeartbeatClass) {
        simulator.injectArrhythmia(rhythm)
    }

    fun setSimulationLeadsOff(isOff: Boolean) {
        simulator.setLeadsOff(isOff)
    }

    fun updateSettings(newSettings: AppSettings) {
        settingsRepo.updateSettings(newSettings)
        applySettingsToDsp(newSettings)
    }

    private fun applySettingsToDsp(s: AppSettings) {
        ecgFilter.updateConfig(
            sampleRate = s.nominalSampleRate,
            vRef = s.vRef,
            adcMax = s.adcMax,
            sensorGain = s.ad8232Gain
        )
        rPeakDetector.updateConfig(
            sampleRate = s.nominalSampleRate,
            refractoryPeriodMs = s.refractoryPeriodMs,
            thresholdMultiplier = s.rPeakThresholdMultiplier
        )
    }

    private fun startSimulationSource() {
        simulationJob?.cancel()
        simulationJob = viewModelScope.launch(Dispatchers.Default) {
            while (isActive && _isMonitoringActive.value) {
                // Generate 15 samples every 60ms (corresponds to 250 Hz)
                val batch = simulator.generateBatch(15)
                val fakePacket = ParsedEcgPacket(
                    latestValue = batch.lastOrNull(),
                    samples = batch,
                    rawPayload = "{\"latest\": ${batch.lastOrNull()}, \"samples\": $batch}"
                )
                processIncomingPacket(fakePacket)
                delay(60L)
            }
        }
    }

    private fun startElapsedTimer() {
        elapsedTimerJob?.cancel()
        elapsedTimerJob = viewModelScope.launch {
            while (isActive && _isMonitoringActive.value) {
                delay(1000L)
                _elapsedMonitoringSeconds.value += 1L
                if (_isRecordingSession.value) {
                    _recordingDurationSeconds.value += 1L
                }
            }
        }
    }

    private fun processIncomingPacket(packet: ParsedEcgPacket) {
        val dspStartNs = System.nanoTime()
        lastRawJsonPayload = packet.rawPayload

        // Ingest through deduplication engine
        val newSamples = deduplicator.extractNewSamples(packet, settings.value.deduplicationMode)
        if (newSamples.isEmpty()) return

        samplesReceivedInLastSec += newSamples.size
        val currentSettings = settings.value

        for (rawAdc in newSamples) {
            _latestAdc.value = rawAdc

            // 1. Calibrate to millivolts
            val rawMv = ecgFilter.rawToMillivolts(rawAdc)

            // 2. Filter signal
            val filteredMv = ecgFilter.filterSample(
                rawMv = rawMv,
                enableBaseline = currentSettings.enableBaselineFilter,
                enableLowPass = currentSettings.enableLowPassFilter,
                enableNotch = currentSettings.enableNotchFilter
            )
            _latestMillivolts.value = filteredMv

            // 3. Assess Signal Quality
            val sqi = signalQualityEstimator.addSample(rawAdc)
            _signalQuality.value = sqi
            val isSignalAdequate = signalQualityEstimator.isSignalAdequate(sqi)

            // Maintain AI beat history buffer
            if (aiSampleHistory.size >= 500) {
                aiSampleHistory.removeFirst()
            }
            aiSampleHistory.addLast(filteredMv)

            // 4. R-Peak Detection
            val isPeak = rPeakDetector.processSample(filteredMv)

            if (isPeak) {
                val now = System.currentTimeMillis()
                _heartBeatPulseTrigger.value = now

                // Haptic feedback
                if (currentSettings.hapticFeedbackOnBeat) {
                    triggerHapticBeat()
                }

                // Compute BPM
                val newBpm = bpmCalculator.onRPeakDetected(now, isSignalAdequate)
                if (newBpm != null) {
                    _bpm.value = newBpm
                    if (_isRecordingSession.value) {
                        recordedBpmList.add(newBpm)
                    }
                }

                if (_isRecordingSession.value) {
                    totalSessionBeats++
                }

                // 5. Trigger On-Device AI Classification if signal is adequate
                if (isSignalAdequate && aiSampleHistory.size >= 250) {
                    classifyCurrentBeat(now)
                }
            }

            // Append to display buffer
            displayPoints[displayHead % displayBufferSize] = filteredMv
            displayHead++

            // Capture snapshot if recording session
            if (_isRecordingSession.value && recordedSnapshots.size < 750) {
                recordedSnapshots.add(filteredMv)
            }
        }

        // Periodically update waveform list for Compose Canvas
        _waveformPoints.value = displayPoints.toList()

        val dspDurationMs = (System.nanoTime() - dspStartNs) / 1_000_000f
        _diagnostics.value = _diagnostics.value.copy(
            dspProcessingTimeMs = dspDurationMs,
            lastReceivedTimestamp = System.currentTimeMillis()
        )
    }

    private fun classifyCurrentBeat(timestamp: Long) {
        val aiStartNs = System.nanoTime()
        val classifier = modelManager.getActiveClassifier()

        // Extract 250-sample window centered around the detected beat
        val window = aiSampleHistory.toList().takeLast(250)
        val rrMs = bpmCalculator.getLastRrIntervalMs().coerceAtLeast(400L)

        val result = classifier.classifyBeat(window, rrMs)
        val aiDurationMs = (System.nanoTime() - aiStartNs) / 1_000_000f

        if (result != null) {
            _lastClassification.value = result

            if (result.predictedClass != HeartbeatClass.NORMAL) {
                // Abnormal beat detected
                if (_isRecordingSession.value) {
                    abnormalSessionBeats++
                }
                val list = _recentArrhythmias.value.toMutableList()
                list.add(0, result)
                if (list.size > 20) list.removeAt(list.size - 1)
                _recentArrhythmias.value = list
            }
        }

        _diagnostics.value = _diagnostics.value.copy(aiInferenceTimeMs = aiDurationMs)
    }

    private fun triggerHapticBeat() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(25)
            }
        } catch (_: Exception) {}
    }

    fun startRecordingSession() {
        if (_isRecordingSession.value) return
        _isRecordingSession.value = true
        _recordingDurationSeconds.value = 0L
        sessionStartTimeMs = System.currentTimeMillis()
        recordedBpmList.clear()
        totalSessionBeats = 0
        abnormalSessionBeats = 0
        recordedSnapshots.clear()
    }

    fun stopAndSaveRecordingSession() {
        if (!_isRecordingSession.value) return
        _isRecordingSession.value = false

        val endTime = System.currentTimeMillis()
        val duration = _recordingDurationSeconds.value.coerceAtLeast(1L)
        val avgBpm = if (recordedBpmList.isNotEmpty()) recordedBpmList.average().toInt() else (_bpm.value ?: 72)
        val minBpm = recordedBpmList.minOrNull() ?: avgBpm
        val maxBpm = recordedBpmList.maxOrNull() ?: avgBpm

        val dominantRhythm = if (abnormalSessionBeats > totalSessionBeats * 0.25f && abnormalSessionBeats > 0) {
            "Arrhythmia Detected ($abnormalSessionBeats beats)"
        } else {
            "Normal Sinus Rhythm"
        }

        val snapshotJson = recordedSnapshots.take(500).joinToString(prefix = "[", postfix = "]")

        val session = EcgSession(
            startTimeMs = sessionStartTimeMs,
            endTimeMs = endTime,
            durationSeconds = duration,
            averageBpm = avgBpm,
            minBpm = minBpm,
            maxBpm = maxBpm,
            dominantRhythm = dominantRhythm,
            totalBeats = totalSessionBeats,
            abnormalBeatsCount = abnormalSessionBeats,
            sourceDescription = if (settings.value.simulationMode) "Simulation Mode" else "ESP8266 + AD8232",
            samplesSnapshotJson = snapshotJson
        )

        viewModelScope.launch(Dispatchers.IO) {
            sessionDao.insertSession(session)
        }
    }

    fun deleteSession(session: EcgSession) {
        viewModelScope.launch(Dispatchers.IO) {
            sessionDao.deleteSession(session)
        }
    }

    fun clearAllSessions() {
        viewModelScope.launch(Dispatchers.IO) {
            sessionDao.clearAll()
        }
    }

    fun loadCustomOnnxModel(uri: Uri) {
        modelManager.loadCustomOnnxModel(uri)
    }

    override fun onCleared() {
        super.onCleared()
        stopMonitoring()
    }
}
