package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppSettings
import com.example.model.DeduplicationMode
import com.example.ui.EcgViewModel
import com.example.ui.theme.EcgGreen
import com.example.ui.theme.MonitorBg
import com.example.ui.theme.MonitorCardBorder
import com.example.ui.theme.MonitorSurface
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun SettingsScreen(
    viewModel: EcgViewModel,
    modifier: Modifier = Modifier
) {
    val currentSettings by viewModel.settings.collectAsState()

    var hostText by remember(currentSettings) { mutableStateOf(currentSettings.espHost) }
    var portText by remember(currentSettings) { mutableStateOf(currentSettings.espPort.toString()) }
    var endpointText by remember(currentSettings) { mutableStateOf(currentSettings.endpointPath) }
    var isWs by remember(currentSettings) { mutableStateOf(currentSettings.isWebSocket) }
    var pollInterval by remember(currentSettings) { mutableFloatStateOf(currentSettings.pollingIntervalMs.toFloat()) }
    var dedupMode by remember(currentSettings) { mutableStateOf(currentSettings.deduplicationMode) }
    var baselineFilter by remember(currentSettings) { mutableStateOf(currentSettings.enableBaselineFilter) }
    var lowPassFilter by remember(currentSettings) { mutableStateOf(currentSettings.enableLowPassFilter) }
    var notchFilter by remember(currentSettings) { mutableStateOf(currentSettings.enableNotchFilter) }
    var thresholdMul by remember(currentSettings) { mutableFloatStateOf(currentSettings.rPeakThresholdMultiplier) }
    var refractoryMs by remember(currentSettings) { mutableFloatStateOf(currentSettings.refractoryPeriodMs.toFloat()) }
    var haptic by remember(currentSettings) { mutableStateOf(currentSettings.hapticFeedbackOnBeat) }
    var simMode by remember(currentSettings) { mutableStateOf(currentSettings.simulationMode) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MonitorBg)
            .verticalScroll(rememberScrollState())
            .padding(14.dp)
            .testTag("settings_screen")
    ) {
        Text(
            text = "HARDWARE & CONNECTION CONFIGURATION",
            color = TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MonitorSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MonitorCardBorder),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // ESP8266 Host IP
                OutlinedTextField(
                    value = hostText,
                    onValueChange = { hostText = it },
                    label = { Text("ESP8266 Host Address") },
                    placeholder = { Text("192.168.4.1") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = EcgGreen,
                        unfocusedBorderColor = MonitorCardBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("esp_host_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = portText,
                        onValueChange = { portText = it },
                        label = { Text("Port") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EcgGreen,
                            unfocusedBorderColor = MonitorCardBorder
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = endpointText,
                        onValueChange = { endpointText = it },
                        label = { Text("Endpoint Path") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EcgGreen,
                            unfocusedBorderColor = MonitorCardBorder
                        ),
                        modifier = Modifier.weight(1.5f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // WebSocket toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Use WebSocket Stream", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Text("Default is HTTP Polling (GET /data)", color = TextMuted, fontSize = 11.sp)
                    }
                    Switch(
                        checked = isWs,
                        onCheckedChange = { isWs = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = EcgGreen)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Polling Interval Slider
                Text(
                    text = "HTTP Polling Interval: ${pollInterval.toInt()} ms (${(1000 / pollInterval).toInt()} req/sec)",
                    color = TextPrimary,
                    fontSize = 12.sp
                )
                Slider(
                    value = pollInterval,
                    onValueChange = { pollInterval = it },
                    valueRange = 40f..250f,
                    colors = SliderDefaults.colors(thumbColor = EcgGreen, activeTrackColor = EcgGreen)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Deduplication mode
                Text("Rolling Buffer Deduplication Mode", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Spacer(modifier = Modifier.height(4.dp))
                DeduplicationMode.entries.forEach { mode ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        androidx.compose.material3.RadioButton(
                            selected = dedupMode == mode,
                            onClick = { dedupMode = mode },
                            colors = androidx.compose.material3.RadioButtonDefaults.colors(selectedColor = EcgGreen)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = mode.label, color = TextPrimary, fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Section: DSP Signal Filtering & R-Peak Settings
        Text(
            text = "DIGITAL SIGNAL PROCESSING (DSP)",
            color = TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MonitorSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MonitorCardBorder),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                SettingSwitchRow(
                    label = "Baseline Drift High-Pass Filter",
                    subtext = "Eliminates 0.6 Hz respiratory baseline wander",
                    checked = baselineFilter,
                    onCheckedChange = { baselineFilter = it }
                )

                SettingSwitchRow(
                    label = "EMG & High-Freq Low-Pass Filter",
                    subtext = "40 Hz cutoff attenuates muscle noise",
                    checked = lowPassFilter,
                    onCheckedChange = { lowPassFilter = it }
                )

                SettingSwitchRow(
                    label = "50 Hz Mains Notch Filter",
                    subtext = "Rejects power line electrical hum",
                    checked = notchFilter,
                    onCheckedChange = { notchFilter = it }
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = String.format(Locale.US, "R-Peak Detection Threshold: %.2fx", thresholdMul),
                    color = TextPrimary,
                    fontSize = 12.sp
                )
                Slider(
                    value = thresholdMul,
                    onValueChange = { thresholdMul = it },
                    valueRange = 0.5f..2.0f,
                    colors = SliderDefaults.colors(thumbColor = TelemetryCyan, activeTrackColor = TelemetryCyan)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Refractory Period: ${refractoryMs.toInt()} ms (blocks T-wave double counts)",
                    color = TextPrimary,
                    fontSize = 12.sp
                )
                Slider(
                    value = refractoryMs,
                    onValueChange = { refractoryMs = it },
                    valueRange = 180f..320f,
                    colors = SliderDefaults.colors(thumbColor = TelemetryCyan, activeTrackColor = TelemetryCyan)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Section: System & Simulation Preferences
        Text(
            text = "SYSTEM & SIMULATION PREFERENCES",
            color = TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MonitorSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MonitorCardBorder),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                SettingSwitchRow(
                    label = "Haptic Vibration on Cardiac Beat",
                    subtext = "Subtle tactile pulse on detected R-peaks",
                    checked = haptic,
                    onCheckedChange = { haptic = it }
                )

                SettingSwitchRow(
                    label = "Hardware Simulation Mode",
                    subtext = "Generate synthetic ECG for offline testing",
                    checked = simMode,
                    onCheckedChange = { simMode = it }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Save & Reset Buttons
        Button(
            onClick = {
                val updated = currentSettings.copy(
                    espHost = hostText.trim().ifEmpty { "192.168.4.1" },
                    espPort = portText.toIntOrNull() ?: 80,
                    endpointPath = endpointText.trim().ifEmpty { "/data" },
                    isWebSocket = isWs,
                    pollingIntervalMs = pollInterval.toLong(),
                    deduplicationMode = dedupMode,
                    enableBaselineFilter = baselineFilter,
                    enableLowPassFilter = lowPassFilter,
                    enableNotchFilter = notchFilter,
                    rPeakThresholdMultiplier = thresholdMul,
                    refractoryPeriodMs = refractoryMs.toInt(),
                    hapticFeedbackOnBeat = haptic,
                    simulationMode = simMode
                )
                viewModel.updateSettings(updated)
            },
            colors = ButtonDefaults.buttonColors(containerColor = EcgGreen, contentColor = Color(0xFF003815)),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("save_settings_button")
        ) {
            Text("APPLY SETTINGS", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedButton(
            onClick = {
                viewModel.updateSettings(AppSettings())
            },
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
        ) {
            Text("RESET TO DEFAULTS", fontSize = 12.sp, color = TextSecondary)
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
private fun SettingSwitchRow(
    label: String,
    subtext: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(label, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(subtext, color = TextMuted, fontSize = 11.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = EcgGreen)
        )
    }
}
