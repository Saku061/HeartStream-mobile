package com.example.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ClassificationResult
import com.example.model.HeartbeatClass
import com.example.model.SignalQuality
import com.example.ui.theme.DisconnectedRed
import com.example.ui.theme.EcgGreen
import com.example.ui.theme.HeartPulseRed
import com.example.ui.theme.MonitorCardBorder
import com.example.ui.theme.MonitorSurface
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AiPredictionCard(
    result: ClassificationResult?,
    signalQuality: SignalQuality,
    isMonitoring: Boolean,
    modifier: Modifier = Modifier
) {
    val isSignalAdequate = signalQuality != SignalQuality.LEADS_OFF && signalQuality != SignalQuality.POOR

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MonitorSurface)
            .border(1.dp, MonitorCardBorder, RoundedCornerShape(12.dp))
            .padding(14.dp)
            .animateContentSize()
            .testTag("ai_prediction_card")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Psychology,
                    contentDescription = "AI Classifier",
                    tint = TelemetryCyan,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "ON-DEVICE AI CLASSIFICATION",
                    color = TextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }
            Text(
                text = "MIT-BIH 1D-CNN",
                color = TelemetryCyan,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (!isMonitoring) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Monitoring paused. Start live streaming to classify beats.",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        } else if (!isSignalAdequate) {
            // Signal insufficient banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(WarningAmber.copy(alpha = 0.12f))
                    .border(1.dp, WarningAmber.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                    .padding(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Warning",
                        tint = WarningAmber,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Signal insufficient for AI inference (${signalQuality.label}). Ensure electrode pads are firmly placed.",
                        color = WarningAmber,
                        fontSize = 11.sp
                    )
                }
            }
        } else if (result == null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Acquiring baseline rhythm... Waiting for confirmed R-peaks.",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        } else {
            // Active prediction card
            val classColor = when (result.predictedClass) {
                HeartbeatClass.NORMAL -> EcgGreen
                HeartbeatClass.APB -> WarningAmber
                HeartbeatClass.LBBB, HeartbeatClass.RBBB -> TelemetryCyan
                HeartbeatClass.PVC -> HeartPulseRed
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(classColor.copy(alpha = 0.18f))
                                .border(1.dp, classColor.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = result.predictedClass.code,
                                color = classColor,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = result.predictedClass.title,
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = result.predictedClass.shortDescription,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${(result.confidence * 100).toInt()}%",
                        color = classColor,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Confidence",
                        color = TextSecondary,
                        fontSize = 10.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Class Probabilities breakdown bars
            Text(
                text = "CLASS PROBABILITIES",
                color = TextSecondary,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            val classes = listOf(
                HeartbeatClass.NORMAL,
                HeartbeatClass.LBBB,
                HeartbeatClass.RBBB,
                HeartbeatClass.APB,
                HeartbeatClass.PVC
            )

            classes.forEach { cls ->
                val prob = result.probabilities[cls] ?: 0f
                val isSelected = cls == result.predictedClass
                val barColor = if (isSelected) classColor else TextMuted

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = cls.code,
                        color = if (isSelected) TextPrimary else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.width(44.dp)
                    )
                    LinearProgressIndicator(
                        progress = { prob },
                        modifier = Modifier
                            .weight(1f)
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = barColor,
                        trackColor = Color(0xFF162534)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = String.format(Locale.US, "%4.1f%%", prob * 100f),
                        color = if (isSelected) classColor else TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.width(42.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Prediction metadata footer
            val timeStr = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(result.timestamp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Time: $timeStr",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "RR: ${result.rrIntervalMs} ms",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
