package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Medical Telemetry Palette
val MonitorBg = Color(0xFF060A0F)
val MonitorSurface = Color(0xFF0D1520)
val MonitorSurfaceVariant = Color(0xFF142030)
val MonitorCardBorder = Color(0xFF1E3146)

// ECG Phosphor Green accents
val EcgGreen = Color(0xFF00E676)
val EcgGreenBright = Color(0xFF00FF66)
val EcgGreenDim = Color(0xFF008947)
val EcgGridMajor = Color(0x3300E676)
val EcgGridMinor = Color(0x1800E676)

// Status & Cardiac accents
val HeartPulseRed = Color(0xFFFF3D71)
val TelemetryCyan = Color(0xFF00E5FF)
val WarningAmber = Color(0xFFFFB300)
val DisconnectedRed = Color(0xFFFF5252)
val QualityGood = Color(0xFF00E676)
val QualityFair = Color(0xFFFFD600)
val QualityPoor = Color(0xFFFF6D00)
val QualityLeadsOff = Color(0xFFFF1744)

// Text tokens
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
