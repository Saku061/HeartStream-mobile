package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.model.EcgSession

@Database(entities = [EcgSession::class], version = 1, exportSchema = false)
abstract class EcgDatabase : RoomDatabase() {
    abstract fun ecgSessionDao(): EcgSessionDao

    companion object {
        @Volatile
        private var INSTANCE: EcgDatabase? = null

        fun getDatabase(context: Context): EcgDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    EcgDatabase::class.java,
                    "heartstream_ecg.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
