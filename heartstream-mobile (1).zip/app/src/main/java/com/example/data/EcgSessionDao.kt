package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.model.EcgSession
import kotlinx.coroutines.flow.Flow

@Dao
interface EcgSessionDao {
    @Query("SELECT * FROM ecg_sessions ORDER BY startTimeMs DESC")
    fun getAllSessions(): Flow<List<EcgSession>>

    @Query("SELECT * FROM ecg_sessions WHERE id = :id")
    suspend fun getSessionById(id: Long): EcgSession?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: EcgSession): Long

    @Delete
    suspend fun deleteSession(session: EcgSession)

    @Query("DELETE FROM ecg_sessions")
    suspend fun clearAll()
}
