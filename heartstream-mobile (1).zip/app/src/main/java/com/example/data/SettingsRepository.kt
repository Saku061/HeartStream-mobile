package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.AppSettings
import com.example.model.DeduplicationMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("heartstream_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun loadSettings(): AppSettings {
        val host = prefs.getString("espHost", "192.168.4.1") ?: "192.168.4.1"
        val port = prefs.getInt("espPort", 80)
        val endpoint = prefs.getString("endpointPath", "/data") ?: "/data"
        val isWs = prefs.getBoolean("isWebSocket", false)
        val pollInterval = prefs.getLong("pollingIntervalMs", 60L)
        val dedupModeStr = prefs.getString("deduplicationMode", DeduplicationMode.OVERLAP_SUFFIX.name)
        val dedupMode = try {
            DeduplicationMode.valueOf(dedupModeStr ?: DeduplicationMode.OVERLAP_SUFFIX.name)
        } catch (_: Exception) {
            DeduplicationMode.OVERLAP_SUFFIX
        }
        val sampleRate = prefs.getInt("nominalSampleRate", 250)
        val adcMax = prefs.getInt("adcMax", 1023)
        val vRef = prefs.getFloat("vRef", 3.3f)
        val gain = prefs.getFloat("ad8232Gain", 1100f)
        val baselineFilter = prefs.getBoolean("enableBaselineFilter", true)
        val lowPassFilter = prefs.getBoolean("enableLowPassFilter", true)
        val notchFilter = prefs.getBoolean("enableNotchFilter", true)
        val thresholdMul = prefs.getFloat("rPeakThresholdMultiplier", 1.0f)
        val refractoryMs = prefs.getInt("refractoryPeriodMs", 220)
        val sweepSpeed = prefs.getFloat("sweepSpeedMmPerSec", 25f)
        val haptic = prefs.getBoolean("hapticFeedbackOnBeat", true)
        val simulation = prefs.getBoolean("simulationMode", false)

        return AppSettings(
            espHost = host,
            espPort = port,
            endpointPath = endpoint,
            isWebSocket = isWs,
            pollingIntervalMs = pollInterval,
            deduplicationMode = dedupMode,
            nominalSampleRate = sampleRate,
            adcMax = adcMax,
            vRef = vRef,
            ad8232Gain = gain,
            enableBaselineFilter = baselineFilter,
            enableLowPassFilter = lowPassFilter,
            enableNotchFilter = notchFilter,
            rPeakThresholdMultiplier = thresholdMul,
            refractoryPeriodMs = refractoryMs,
            sweepSpeedMmPerSec = sweepSpeed,
            hapticFeedbackOnBeat = haptic,
            simulationMode = simulation
        )
    }

    fun updateSettings(newSettings: AppSettings) {
        prefs.edit().apply {
            putString("espHost", newSettings.espHost)
            putInt("espPort", newSettings.espPort)
            putString("endpointPath", newSettings.endpointPath)
            putBoolean("isWebSocket", newSettings.isWebSocket)
            putLong("pollingIntervalMs", newSettings.pollingIntervalMs)
            putString("deduplicationMode", newSettings.deduplicationMode.name)
            putInt("nominalSampleRate", newSettings.nominalSampleRate)
            putInt("adcMax", newSettings.adcMax)
            putFloat("vRef", newSettings.vRef)
            putFloat("ad8232Gain", newSettings.ad8232Gain)
            putBoolean("enableBaselineFilter", newSettings.enableBaselineFilter)
            putBoolean("enableLowPassFilter", newSettings.enableLowPassFilter)
            putBoolean("enableNotchFilter", newSettings.enableNotchFilter)
            putFloat("rPeakThresholdMultiplier", newSettings.rPeakThresholdMultiplier)
            putInt("refractoryPeriodMs", newSettings.refractoryPeriodMs)
            putFloat("sweepSpeedMmPerSec", newSettings.sweepSpeedMmPerSec)
            putBoolean("hapticFeedbackOnBeat", newSettings.hapticFeedbackOnBeat)
            putBoolean("simulationMode", newSettings.simulationMode)
            apply()
        }
        _settings.value = newSettings
    }
}
