package com.example.dsp

import com.example.model.SignalQuality
import kotlin.math.sqrt

/**
 * Evaluates real-time ECG signal quality index (SQI).
 * Monitors:
 * 1. AD8232 rail saturation (LO+ / LO- electrode detachment causes 0 or 1023 ADC)
 * 2. Flatline / zero standard deviation
 * 3. Peak-to-peak dynamic range & baseline wander ratio
 */
class SignalQualityEstimator(
    private val windowSize: Int = 200,
    private val adcMax: Int = 1023
) {
    private val adcWindow = IntArray(windowSize)
    private var windowIdx = 0
    private var sampleCount = 0

    fun addSample(rawAdc: Int): SignalQuality {
        adcWindow[windowIdx % windowSize] = rawAdc
        windowIdx++
        if (sampleCount < windowSize) {
            sampleCount++
            return SignalQuality.GOOD
        }

        // 1. Check for AD8232 saturation / leads-off condition
        // AD8232 output rails to GND (< 20) or VDD (> adcMax - 20) when electrodes disconnect
        var saturatedCount = 0
        var sum = 0.0
        var minVal = Int.MAX_VALUE
        var maxVal = Int.MIN_VALUE

        for (v in adcWindow) {
            if (v < 20 || v > adcMax - 20) {
                saturatedCount++
            }
            if (v < minVal) minVal = v
            if (v > maxVal) maxVal = v
            sum += v
        }

        // If more than 30% of samples are railed to GND/VDD, leads are off
        if (saturatedCount > windowSize * 0.3f) {
            return SignalQuality.LEADS_OFF
        }

        val range = maxVal - minVal
        // If range is extremely tiny (< 8 ADC counts), sensor is flatlining/unconnected
        if (range < 8) {
            return SignalQuality.LEADS_OFF
        }

        // Calculate standard deviation
        val mean = sum / windowSize
        var varianceSum = 0.0
        for (v in adcWindow) {
            val diff = v - mean
            varianceSum += diff * diff
        }
        val stdDev = sqrt(varianceSum / windowSize)

        if (stdDev < 3.0) {
            return SignalQuality.LEADS_OFF
        }

        // Evaluate dynamic range & quality index
        return when {
            range in 60..500 && stdDev in 15.0..120.0 -> SignalQuality.EXCELLENT
            range in 40..650 && stdDev in 10.0..180.0 -> SignalQuality.GOOD
            range in 20..850 -> SignalQuality.FAIR
            else -> SignalQuality.POOR
        }
    }

    fun isSignalAdequate(quality: SignalQuality): Boolean {
        return quality == SignalQuality.EXCELLENT ||
               quality == SignalQuality.GOOD ||
               quality == SignalQuality.FAIR
    }

    fun reset() {
        adcWindow.fill(512)
        windowIdx = 0
        sampleCount = 0
    }
}
