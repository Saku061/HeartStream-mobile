package com.example.dsp

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * High-performance real-time DSP filter chain for single-lead AD8232 ECG.
 * Includes:
 * 1. ADC to millivolts calibration
 * 2. Baseline wander removal (0.6 Hz high-pass IIR)
 * 3. Mains noise suppression (50/60 Hz notch filter)
 * 4. High-frequency muscle noise filter (40 Hz low-pass)
 */
class EcgFilter(
    private var sampleRate: Int = 250,
    private var vRef: Float = 3.3f,
    private var adcMax: Int = 1023,
    private var sensorGain: Float = 1100f
) {
    // Baseline high-pass filter state (approx 0.67 Hz cutoff)
    private var hpPrevX = 0f
    private var hpPrevY = 0f
    private val hpAlpha: Float
        get() = 1f / (1f + 2f * PI.toFloat() * 0.67f / sampleRate)

    // Low-pass filter state (approx 40 Hz cutoff)
    private var lpPrevY = 0f
    private val lpAlpha: Float
        get() {
            val rc = 1f / (2f * PI.toFloat() * 40f)
            val dt = 1f / sampleRate
            return dt / (rc + dt)
        }

    // 50 Hz Notch filter (2nd order IIR)
    private var notchX1 = 0f
    private var notchX2 = 0f
    private var notchY1 = 0f
    private var notchY2 = 0f

    fun updateConfig(
        sampleRate: Int,
        vRef: Float,
        adcMax: Int,
        sensorGain: Float
    ) {
        this.sampleRate = sampleRate
        this.vRef = vRef
        this.adcMax = adcMax
        this.sensorGain = sensorGain
    }

    /**
     * Converts raw 10-bit ADC integer (0..1023) to physiological millivolts (mV).
     * AD8232 virtual ground is at Vref / 2 (~1.65V on 3.3V boards, corresponding to ADC ~512).
     */
    fun rawToMillivolts(rawAdc: Int): Float {
        val midAdc = adcMax / 2.0f
        val deltaAdc = rawAdc - midAdc
        val voltageAtPin = (deltaAdc / adcMax.toFloat()) * vRef
        // Millivolts of biological cardiac potential before sensor gain
        return (voltageAtPin / sensorGain) * 1000f
    }

    /**
     * Applies the configured filtering pipeline to a millivolt sample.
     */
    fun filterSample(
        rawMv: Float,
        enableBaseline: Boolean = true,
        enableLowPass: Boolean = true,
        enableNotch: Boolean = true
    ): Float {
        var sample = rawMv

        // 1. Baseline wander high-pass
        if (enableBaseline) {
            val y = hpAlpha * (hpPrevY + sample - hpPrevX)
            hpPrevX = sample
            hpPrevY = y
            sample = y
        } else {
            hpPrevX = sample
        }

        // 2. 50 Hz Notch filter
        if (enableNotch) {
            val f0 = 50f
            val omega0 = 2f * PI.toFloat() * f0 / sampleRate
            val r = 0.95f
            val b0 = 1f
            val b1 = -2f * cos(omega0)
            val b2 = 1f
            val a1 = -2f * r * cos(omega0)
            val a2 = r * r

            val yNotch = b0 * sample + b1 * notchX1 + b2 * notchX2 - a1 * notchY1 - a2 * notchY2
            notchX2 = notchX1
            notchX1 = sample
            notchY2 = notchY1
            notchY1 = yNotch
            sample = yNotch
        }

        // 3. Low-pass EMG & noise filter (40 Hz)
        if (enableLowPass) {
            val yLp = lpPrevY + lpAlpha * (sample - lpPrevY)
            lpPrevY = yLp
            sample = yLp
        } else {
            lpPrevY = sample
        }

        return sample
    }

    fun reset() {
        hpPrevX = 0f
        hpPrevY = 0f
        lpPrevY = 0f
        notchX1 = 0f
        notchX2 = 0f
        notchY1 = 0f
        notchY2 = 0f
    }
}
