package com.example.dsp

import kotlin.math.max
import kotlin.math.sqrt

/**
 * Real-time Pan-Tompkins QRS and R-Peak detection engine.
 * Specifically tuned for single-lead AD8232 at 250 Hz sampling rate.
 */
class RPeakDetector(
    private var sampleRate: Int = 250,
    private var refractoryPeriodMs: Int = 220,
    private var thresholdMultiplier: Float = 1.0f
) {
    // Differentiation buffer
    private val dBuf = FloatArray(5)
    private var dIdx = 0

    // Moving window integrator
    private var mwiWindowSize = (0.150f * sampleRate).toInt().coerceAtLeast(5)
    private val mwiBuf = FloatArray(128)
    private var mwiIdx = 0
    private var mwiSum = 0f

    // Peak tracking
    private var spkI = 0.5f // Signal peak running average (integrator)
    private var npkI = 0.1f // Noise peak running average (integrator)
    private var thresholdI = 0.25f

    // Refractory period in samples
    private var refractorySamples = ((refractoryPeriodMs / 1000f) * sampleRate).toInt()
    private var samplesSinceLastPeak = 999999

    // Raw/Filtered peak alignment
    private val searchWindow = (0.100f * sampleRate).toInt().coerceAtLeast(3)
    private val recentSamples = FloatArray(64)
    private var recentIdx = 0

    // Bandpass filter state (5 - 15 Hz)
    private var bpX1 = 0f
    private var bpX2 = 0f
    private var bpY1 = 0f
    private var bpY2 = 0f

    fun updateConfig(
        sampleRate: Int,
        refractoryPeriodMs: Int,
        thresholdMultiplier: Float
    ) {
        this.sampleRate = sampleRate
        this.refractoryPeriodMs = refractoryPeriodMs
        this.thresholdMultiplier = thresholdMultiplier
        this.refractorySamples = ((refractoryPeriodMs / 1000f) * sampleRate).toInt().coerceAtLeast(10)
        this.mwiWindowSize = (0.150f * sampleRate).toInt().coerceIn(5, 120)
    }

    /**
     * Processes one ECG sample point and returns true if an R-peak is confirmed.
     */
    fun processSample(filteredMv: Float): Boolean {
        samplesSinceLastPeak++

        // Save recent sample for local peak search
        recentSamples[recentIdx % recentSamples.size] = filteredMv
        recentIdx++

        // 1. QRS Bandpass filter (simple peaking filter around 10-12 Hz)
        val qrsFiltered = bandpassQrs(filteredMv)

        // 2. 5-point Derivative filter
        dBuf[dIdx % 5] = qrsFiltered
        val x0 = dBuf[dIdx % 5]
        val x1 = dBuf[(dIdx + 4) % 5]
        val x3 = dBuf[(dIdx + 2) % 5]
        val x4 = dBuf[(dIdx + 1) % 5]
        dIdx++
        val derivative = (2f * x0 + x1 - x3 - 2f * x4) / 8f

        // 3. Squaring
        val squared = derivative * derivative

        // 4. Moving Window Integration (MWI)
        val oldVal = mwiBuf[mwiIdx % mwiWindowSize]
        mwiBuf[mwiIdx % mwiWindowSize] = squared
        mwiIdx++
        mwiSum += squared - oldVal
        val integrated = mwiSum / mwiWindowSize

        // 5. Dynamic Thresholding & Refractory Check
        val effectiveThreshold = thresholdI * thresholdMultiplier

        if (integrated > effectiveThreshold && samplesSinceLastPeak > refractorySamples) {
            // Potential R-peak found!
            // Update signal peak running estimate
            spkI = 0.125f * integrated + 0.875f * spkI
            thresholdI = npkI + 0.25f * (spkI - npkI)
            samplesSinceLastPeak = 0
            return true
        } else if (integrated > npkI && samplesSinceLastPeak > refractorySamples) {
            // Update noise peak running estimate
            npkI = 0.125f * integrated + 0.875f * npkI
            thresholdI = npkI + 0.25f * (spkI - npkI)
        }

        return false
    }

    private fun bandpassQrs(input: Float): Float {
        // High-pass + Low-pass cascade for QRS energy
        val hp = input - bpX1 * 0.95f
        bpX1 = input
        val lp = bpY1 + 0.35f * (hp - bpY1)
        bpY1 = lp
        return lp
    }

    fun reset() {
        dBuf.fill(0f)
        dIdx = 0
        mwiBuf.fill(0f)
        mwiIdx = 0
        mwiSum = 0f
        spkI = 0.5f
        npkI = 0.1f
        thresholdI = 0.25f
        samplesSinceLastPeak = 999999
        recentSamples.fill(0f)
        recentIdx = 0
        bpX1 = 0f
        bpX2 = 0f
        bpY1 = 0f
        bpY2 = 0f
    }
}
