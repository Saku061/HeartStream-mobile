package com.example.dsp

import java.util.ArrayDeque

/**
 * Calculates physiological Heart Rate (BPM) from R-R intervals with
 * physiological boundary validation, outlier rejection, and moving median smoothing.
 */
class BpmCalculator(
    private val bufferSize: Int = 6
) {
    private var lastPeakTimestampMs: Long = 0L
    private val recentRrIntervalsMs = ArrayDeque<Long>(bufferSize)
    private var currentBpm: Int = 0
    private var validBeatCount: Long = 0L

    /**
     * Registers a new detected R-peak at [timestampMs].
     * Returns the updated BPM, or null if interval is rejected as implausible.
     */
    fun onRPeakDetected(timestampMs: Long, isSignalAdequate: Boolean): Int? {
        if (!isSignalAdequate) {
            // Signal degraded (leads off / extreme noise); suppress calculation
            return if (currentBpm > 0) currentBpm else null
        }

        if (lastPeakTimestampMs == 0L) {
            lastPeakTimestampMs = timestampMs
            return null
        }

        val rrIntervalMs = timestampMs - lastPeakTimestampMs
        lastPeakTimestampMs = timestampMs

        // Physiological plausibility filter:
        // 30 BPM corresponds to 2000 ms; 240 BPM corresponds to 250 ms.
        if (rrIntervalMs < 250L || rrIntervalMs > 2200L) {
            // Implausible R-R interval (e.g. false double-trigger or paused acquisition)
            return if (currentBpm > 0) currentBpm else null
        }

        // Outlier rejection compared to moving median:
        if (recentRrIntervalsMs.size >= 3) {
            val median = getMedian(recentRrIntervalsMs)
            val deviation = kotlin.math.abs(rrIntervalMs - median)
            // If sudden jump exceeds 45% of median, reject single spurious interval
            if (deviation > median * 0.45f) {
                return currentBpm
            }
        }

        if (recentRrIntervalsMs.size >= bufferSize) {
            recentRrIntervalsMs.removeFirst()
        }
        recentRrIntervalsMs.addLast(rrIntervalMs)
        validBeatCount++

        val smoothedRr = getMedian(recentRrIntervalsMs)
        val calculatedBpm = (60_000.0 / smoothedRr).toInt().coerceIn(30, 240)
        currentBpm = calculatedBpm
        return calculatedBpm
    }

    fun getCurrentBpm(isSignalAdequate: Boolean): Int? {
        if (!isSignalAdequate || recentRrIntervalsMs.isEmpty()) return null
        return currentBpm
    }

    fun getLastRrIntervalMs(): Long {
        return recentRrIntervalsMs.lastOrNull() ?: 0L
    }

    fun getValidBeatCount(): Long = validBeatCount

    private fun getMedian(list: Collection<Long>): Double {
        if (list.isEmpty()) return 0.0
        val sorted = list.sorted()
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 1) {
            sorted[middle].toDouble()
        } else {
            (sorted[middle - 1] + sorted[middle]) / 2.0
        }
    }

    fun reset() {
        lastPeakTimestampMs = 0L
        recentRrIntervalsMs.clear()
        currentBpm = 0
        validBeatCount = 0L
    }
}
