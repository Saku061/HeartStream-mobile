package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ecg_sessions")
data class EcgSession(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val durationSeconds: Long,
    val averageBpm: Int,
    val minBpm: Int,
    val maxBpm: Int,
    val dominantRhythm: String,
    val totalBeats: Int,
    val abnormalBeatsCount: Int,
    val sourceDescription: String = "ESP8266 + AD8232",
    val samplesSnapshotJson: String = "" // Sample excerpt for replay
)
