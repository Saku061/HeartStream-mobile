package com.example.model

/**
 * Represents a single ECG sample point with raw and calibrated values.
 */
data class EcgSample(
    val timestampMs: Long,
    val rawAdc: Int,
    val millivolts: Float,
    val filteredMv: Float,
    val isRPeak: Boolean = false
)

enum class HeartbeatClass(
    val code: String,
    val title: String,
    val shortDescription: String
) {
    NORMAL("N", "Normal Sinus", "Standard SA-AV cardiac conduction cycle"),
    LBBB("LBBB", "Left Bundle Branch Block", "Delayed left ventricular conduction with wide QRS"),
    RBBB("RBBB", "Right Bundle Branch Block", "Delayed right ventricular depolarization (rsR' pattern)"),
    APB("APB", "Atrial Premature Beat", "Early ectopic atrial firing (premature contraction)"),
    PVC("PVC", "Premature Ventricular Contraction", "Ectopic ventricular origin, widened & bizarre QRS");

    companion object {
        fun fromCode(code: String): HeartbeatClass {
            return entries.firstOrNull { it.code.equals(code, ignoreCase = true) || it.name.equals(code, ignoreCase = true) }
                ?: NORMAL
        }
    }
}

data class ClassificationResult(
    val predictedClass: HeartbeatClass,
    val confidence: Float,
    val probabilities: Map<HeartbeatClass, Float>,
    val timestamp: Long,
    val rrIntervalMs: Long,
    val beatSamples: List<Float>,
    val engineName: String
)

enum class SignalQuality(val label: String) {
    EXCELLENT("Optimal (Low Noise)"),
    GOOD("Good"),
    FAIR("Fair (Slight Motion)"),
    POOR("Poor (Excessive Noise)"),
    LEADS_OFF("Leads Off / Sensor Disconnected")
}

enum class ConnectionStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    RECONNECTING,
    ERROR
}

data class ConnectionInfo(
    val status: ConnectionStatus = ConnectionStatus.DISCONNECTED,
    val host: String = "192.168.4.1",
    val latencyMs: Long = 0L,
    val message: String = "Idle"
)
