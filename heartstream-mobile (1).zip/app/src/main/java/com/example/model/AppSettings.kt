package com.example.model

data class AppSettings(
    val espHost: String = "192.168.4.1",
    val espPort: Int = 80,
    val endpointPath: String = "/data",
    val isWebSocket: Boolean = false,
    val pollingIntervalMs: Long = 60L,
    val deduplicationMode: DeduplicationMode = DeduplicationMode.OVERLAP_SUFFIX,
    val nominalSampleRate: Int = 250,
    val adcMax: Int = 1023,
    val vRef: Float = 3.3f,
    val ad8232Gain: Float = 1100f,
    val enableBaselineFilter: Boolean = true,
    val enableLowPassFilter: Boolean = true,
    val enableNotchFilter: Boolean = true,
    val rPeakThresholdMultiplier: Float = 1.0f,
    val refractoryPeriodMs: Int = 220,
    val sweepSpeedMmPerSec: Float = 25f,
    val hapticFeedbackOnBeat: Boolean = true,
    val simulationMode: Boolean = false,
    val selectedModel: String = "EMBEDDED_NEURAL_1DCNN" // or "ONNX_EXTERNAL"
)

enum class DeduplicationMode(val label: String) {
    OVERLAP_SUFFIX("Rolling Buffer Suffix Matching (Recommended)"),
    SEQUENCE_ID("Sequence Number / Timestamp Tag"),
    DISABLED("Disabled (Append all buffer arrays)")
}

data class DiagnosticsInfo(
    val receivedSamplesPerSec: Float = 0f,
    val droppedSamplesCount: Long = 0L,
    val duplicateBuffersSuppressed: Long = 0L,
    val bufferSize: Int = 0,
    val latencyRttMs: Long = 0L,
    val dspProcessingTimeMs: Float = 0f,
    val aiInferenceTimeMs: Float = 0f,
    val lastReceivedTimestamp: Long = 0L,
    val lastRawPayload: String = "{}"
)
