package com.example.ai

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

/**
 * Manages the active on-device AI inference model, custom model imports,
 * model status, and diagnostics.
 */
class ModelManager(private val context: Context) {

    private val embeddedClassifier = EmbeddedEcgNetClassifier()

    private val _currentClassifier = MutableStateFlow<EcgClassifier>(embeddedClassifier)
    val currentClassifier: StateFlow<EcgClassifier> = _currentClassifier.asStateFlow()

    private val _modelStatusText = MutableStateFlow("ECGNet 1D-CNN (Embedded On-Device)")
    val modelStatusText: StateFlow<String> = _modelStatusText.asStateFlow()

    private val _isExternalModelLoaded = MutableStateFlow(false)
    val isExternalModelLoaded: StateFlow<Boolean> = _isExternalModelLoaded.asStateFlow()

    fun loadCustomOnnxModel(uri: Uri) {
        try {
            // Copy custom .onnx model to app internal cache
            val inputStream = context.contentResolver.openInputStream(uri)
            val modelFile = File(context.filesDir, "custom_ecgnet.onnx")
            inputStream?.use { input ->
                modelFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            if (modelFile.exists() && modelFile.length() > 0) {
                _isExternalModelLoaded.value = true
                _modelStatusText.value = "Custom ONNX: ${modelFile.name} (${modelFile.length() / 1024} KB)"
            }
        } catch (e: Exception) {
            _modelStatusText.value = "Model Import Error: ${e.localizedMessage}"
        }
    }

    fun useEmbeddedModel() {
        _currentClassifier.value = embeddedClassifier
        _modelStatusText.value = "ECGNet 1D-CNN (Embedded On-Device)"
        _isExternalModelLoaded.value = false
    }

    fun getActiveClassifier(): EcgClassifier = _currentClassifier.value
}
