package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Color
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectionStatus
import com.example.ui.EcgViewModel
import com.example.ui.screens.AiDiagnosticsScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.GuideScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.DisconnectedRed
import com.example.ui.theme.EcgGreen
import com.example.ui.theme.HeartStreamTheme
import com.example.ui.theme.MonitorBg
import com.example.ui.theme.MonitorCardBorder
import com.example.ui.theme.MonitorSurface
import com.example.ui.theme.TelemetryCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber

enum class NavDestination(val title: String, val icon: ImageVector, val testTag: String) {
    MONITOR("Monitor", Icons.Default.ShowChart, "tab_monitor"),
    HISTORY("History", Icons.Default.History, "tab_history"),
    DIAGNOSTICS("AI & Diag", Icons.Default.Psychology, "tab_diagnostics"),
    SETTINGS("Settings", Icons.Default.Settings, "tab_settings"),
    GUIDE("Guide", Icons.Default.HelpOutline, "tab_guide")
}

class MainActivity : ComponentActivity() {

    private val viewModel: EcgViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            HeartStreamTheme {
                var currentTab by remember { mutableStateOf(NavDestination.MONITOR) }
                val connectionInfo by viewModel.connectionInfo.collectAsState()
                val isMonitoring by viewModel.isMonitoringActive.collectAsState()
                val settings by viewModel.settings.collectAsState()

                // Handle back press: return to MONITOR tab if on another screen
                BackHandler(enabled = currentTab != NavDestination.MONITOR) {
                    currentTab = NavDestination.MONITOR
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = MonitorBg,
                    topBar = {
                        TopAppBar(
                            title = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // Animated status dot
                                    val dotColor = when (connectionInfo.status) {
                                        ConnectionStatus.CONNECTED -> EcgGreen
                                        ConnectionStatus.CONNECTING -> TelemetryCyan
                                        ConnectionStatus.RECONNECTING -> WarningAmber
                                        ConnectionStatus.DISCONNECTED -> TextMuted
                                        ConnectionStatus.ERROR -> DisconnectedRed
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(dotColor)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "HEARTSTREAM",
                                        color = TextPrimary,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 1.5.sp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (settings.simulationMode) "SIM" else "LIVE",
                                        color = if (settings.simulationMode) WarningAmber else EcgGreen,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .background(
                                                (if (settings.simulationMode) WarningAmber else EcgGreen).copy(alpha = 0.15f)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MonitorSurface,
                                titleContentColor = TextPrimary
                            ),
                            modifier = Modifier.border(
                                width = 1.dp,
                                color = MonitorCardBorder
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = MonitorSurface,
                            modifier = Modifier.border(1.dp, MonitorCardBorder)
                        ) {
                            NavDestination.entries.forEach { destination ->
                                val selected = currentTab == destination
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { currentTab = destination },
                                    icon = {
                                        Icon(
                                            imageVector = destination.icon,
                                            contentDescription = destination.title,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = destination.title,
                                            fontSize = 10.sp,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = EcgGreen,
                                        selectedTextColor = EcgGreen,
                                        unselectedIconColor = TextMuted,
                                        unselectedTextColor = TextMuted,
                                        indicatorColor = Color(0xFF14291E)
                                    ),
                                    modifier = Modifier.testTag(destination.testTag)
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            NavDestination.MONITOR -> DashboardScreen(viewModel = viewModel)
                            NavDestination.HISTORY -> HistoryScreen(viewModel = viewModel)
                            NavDestination.DIAGNOSTICS -> AiDiagnosticsScreen(viewModel = viewModel)
                            NavDestination.SETTINGS -> SettingsScreen(viewModel = viewModel)
                            NavDestination.GUIDE -> GuideScreen()
                        }
                    }
                }
            }
        }
    }
}
