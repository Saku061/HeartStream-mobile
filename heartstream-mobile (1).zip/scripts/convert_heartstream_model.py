#!/usr/bin/env python3
"""
HeartStream PyTorch to ONNX Model Conversion Script
===================================================
Converts 'best_model.pth' or 'final_model.pth' from the HeartStream
repository (https://github.com/ayushilathiya/HeartStream) into an
ONNX mobile-compatible model format.

Usage:
    python convert_heartstream_model.py --weights best_model.pth --output heartstream_ecgnet.onnx

Heartbeat Classes (MIT-BIH Arrhythmia Database):
    0: Normal Sinus Beat (N)
    1: Left Bundle Branch Block (LBBB)
    2: Right Bundle Branch Block (RBBB)
    3: Atrial Premature Beat (APB / PAC)
    4: Premature Ventricular Contraction (PVC)
"""

import os
import sys
import argparse
import torch
import torch.nn as nn
import numpy as np

# Recreate the ECGNet 1D-CNN architecture from src/models/ecgnet.py
class ECGNet(nn.Module):
    def __init__(self, num_classes=5):
        super(ECGNet, self).__init__()
        # Conv block 1
        self.conv1 = nn.Conv1d(in_channels=1, out_channels=16, kernel_size=7, stride=1, padding=3)
        self.bn1 = nn.BatchNorm1d(16)
        self.relu1 = nn.ReLU()
        self.pool1 = nn.MaxPool1d(kernel_size=2, stride=2)

        # Conv block 2
        self.conv2 = nn.Conv1d(in_channels=16, out_channels=32, kernel_size=5, stride=1, padding=2)
        self.bn2 = nn.BatchNorm1d(32)
        self.relu2 = nn.ReLU()
        self.pool2 = nn.MaxPool1d(kernel_size=2, stride=2)

        # Conv block 3
        self.conv3 = nn.Conv1d(in_channels=32, out_channels=64, kernel_size=3, stride=1, padding=1)
        self.bn3 = nn.BatchNorm1d(64)
        self.relu3 = nn.ReLU()
        self.pool3 = nn.MaxPool1d(kernel_size=2, stride=2)

        # Classifier head
        self.global_pool = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Linear(64, num_classes)
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x):
        # Input shape: [batch, 1, 250]
        x = self.pool1(self.relu1(self.bn1(self.conv1(x))))
        x = self.pool2(self.relu2(self.bn2(self.conv2(x))))
        x = self.pool3(self.relu3(self.bn3(self.conv3(x))))
        x = self.global_pool(x)
        x = x.squeeze(-1)
        logits = self.fc(x)
        probs = self.softmax(logits)
        return probs

def convert(weights_path, output_path):
    print(f"[*] Initializing ECGNet (5 arrhythmia classes)...")
    model = ECGNet(num_classes=5)

    if os.path.exists(weights_path):
        print(f"[*] Loading PyTorch weights from: {weights_path}")
        state_dict = torch.load(weights_path, map_location='cpu')
        # Handle state_dict if wrapped in a dict
        if 'model_state_dict' in state_dict:
            state_dict = state_dict['model_state_dict']
        model.load_state_dict(state_dict)
        print("[+] Weights loaded successfully!")
    else:
        print(f"[!] Warning: '{weights_path}' not found. Generating template ONNX with initialized weights.")

    model.eval()

    # Preprocessing verification:
    # 250 samples window @ 250 Hz (1 second duration)
    dummy_input = torch.randn(1, 1, 250)
    
    with torch.no_grad():
        test_out = model(dummy_input)
        print(f"[*] Sanity check inference output shape: {test_out.shape}")
        print(f"[*] Test probabilities sum: {test_out.sum().item():.4f}")

    print(f"[*] Exporting ONNX model to: {output_path}")
    torch.onnx.export(
        model,
        dummy_input,
        output_path,
        export_params=True,
        opset_version=13,
        do_constant_folding=True,
        input_names=['ecg_signal'],
        output_names=['class_probabilities'],
        dynamic_axes={
            'ecg_signal': {0: 'batch_size'},
            'class_probabilities': {0: 'batch_size'}
        }
    )
    print(f"[+] SUCCESS! Model exported to '{output_path}'.")
    print(f"[*] You can now transfer '{output_path}' to your Android phone and load it in HeartStream!")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="HeartStream PyTorch to ONNX Converter")
    parser.add_argument("--weights", default="best_model.pth", help="Path to best_model.pth or final_model.pth")
    parser.add_argument("--output", default="heartstream_ecgnet.onnx", help="Output .onnx model filename")
    args = parser.parse_args()
    convert(args.weights, args.output)
